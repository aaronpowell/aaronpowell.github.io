﻿USE [DDDSydney]
GO

/****** Object:  Table [dbo].[Session]    Script Date: 04/23/2010 18:51:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Session](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](50) NOT NULL,
	[Abstract] [nvarchar](max) NOT NULL,
	[PresenterId] [int] NOT NULL,
	[FullSession] [bit] NOT NULL,
	[Created] [datetime] NOT NULL,
 CONSTRAINT [PK_Session] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

USE [DDDSydney]
GO

/****** Object:  Table [dbo].[Presenter]    Script Date: 04/23/2010 18:51:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Presenter](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](255) NOT NULL,
	[Email] [nvarchar](255) NOT NULL,
	[Website] [nvarchar](255) NULL,
	[Twitter] [nvarchar](50) NULL,
 CONSTRAINT [PK_Presenter] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

USE [DDDSydney]
GO

/****** Object:  Table [dbo].[Vote]    Script Date: 04/23/2010 18:51:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Vote](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Created] [datetime] NOT NULL,
	[SessionId] [int] NOT NULL,
	[IP] [nchar](15) NOT NULL,
 CONSTRAINT [PK_Vote] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Session]  WITH CHECK ADD  CONSTRAINT [FK_Session_Presenter] FOREIGN KEY([PresenterId])
REFERENCES [dbo].[Presenter] ([Id])
GO

ALTER TABLE [dbo].[Session] CHECK CONSTRAINT [FK_Session_Presenter]
GO

ALTER TABLE [dbo].[Vote]  WITH CHECK ADD  CONSTRAINT [FK_Vote_Session] FOREIGN KEY([SessionId])
REFERENCES [dbo].[Session] ([Id])
GO

ALTER TABLE [dbo].[Vote] CHECK CONSTRAINT [FK_Vote_Session]
GO

