﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace DddSydney.Models
{
    public partial class DddSydneyDataContext
    {
    }

    [MetadataType(typeof(SessionMetaData))]
    public partial class Session
    {
        public class SessionMetaData
        {
            [Required]
            [DisplayName("Session Name")]
            public object Title { get; set; }

            [Required]
            [DisplayName("Session Abstract")]
            public object Abstract { get; set; }

            [Required]
            [DisplayName("Session Type")]
            public object FullSession { get; set; }

            //non editable properties
            [ScaffoldColumn(true)]
            public object Id { get; set; }

            [ScaffoldColumn(true)]
            public object PresenterId { get; set; }

            [ScaffoldColumn(true)]
            [DefaultValue(DateTime.Now)]
            public object Created { get; set; }
        }
    }

    [MetadataType(typeof(PresenterMetaData))]
    public class Presenter
    {
        public class PresenterMetaData
        {
            [Required]
            [DisplayName("Name")]
            public object Name { get; set; }

            [Required]
            [DisplayName("Email")]
            [DataType(DataType.EmailAddress)]
            public object Email { get; set; }

            [DisplayName("Website")]
            public object Website { get; set; }

            [DisplayName("Twitter username")]
            public object Twitter { get; set; }

            //non editable fields
            [ScaffoldColumn(true)]
            public bool Id { get; set; }
        }
    }

    [MetadataType(typeof(VoteMetaData))]
    public class Vote
    {
        public class VoteMetaData
        {
            //non editable properties
            [ScaffoldColumn(true)]
            public object Id { get; set; }

            [ScaffoldColumn(true)]
            public object SessionId { get; set; }

            [ScaffoldColumn(true)]
            [DefaultValue(DateTime.Now)]
            public object Created { get; set; }

        }
    }
}