﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DddSydney.Models
{
    public class SessionModel
    {
        class SessionInfo
        {
            public int SessionId { get; set; }
            public string PresenterName { get; set; }
            public string PresenterWebsite { get; set; }
            public string Title { get; set; }
            public string Abstract { get; set; }
        }
    }
}