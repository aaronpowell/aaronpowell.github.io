﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Rhino.Mocks;
using WebFormsMvp;
using CodeGarden10.Logic.Views.Models;
using TheFarm.Snapshot.Abstractions.Services;
using TheFarm.Snapshot.Abstractions.Models;
using CodeGarden10.Logic.Services;
using CodeGarden10.Logic.Presenters;
using CodeGarden10.Logic.Views;

namespace CodeGarden10.Logic.Tests
{
    [TestClass]
    public class ListGalleriesPresenterTests
    {
        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void ListGalleriesPresenterTests_No_Galleries_Throws_Exception()
        {
            //Arrange
            var view = MockRepository.GenerateStub<IListGalleriesView>();

            var ctx = MockRepository.GenerateStub<ICodeGarden10DataContext>();
            ctx.Stub(x => x.CWS_Galleriess).Return(new List<ICWS_Galleries>());

            var presenter = new ListGalleriesPresenter(view, ctx);


            //Act
            view.Raise(x => x.Load += null, null, null);
            presenter.ReleaseView();

            //Assert
            Assert.Fail("Exception was not thrown");
        }

        //[TestMethod]
        //public void ListGalleriesPresenterTests_Data_Loaded_From_DataContext()
        //{
        //    //Arrange
        //    var view = MockRepository.GenerateStub<IView<ListGalleriesModel>>();
        //    var contentService = MockRepository.GenerateStub<IContentService>();
        //    var node = MockRepository.GenerateStub<INode>();
        //    node.Stub(x => x.Id).Return(0);
        //    contentService.Stub(x => x.GetCurrent()).Return(node);

        //    var gallery = MockRepository.GenerateStub<ICWS_Galleries>();
        //    gallery.Stub(x => x.Id).Return(0);
        //    gallery.Stub(x => x.CWS_Gallerys).Return(new List<ICWS_Gallery>());
        //    var ctx = MockRepository.GenerateStub<ICodeGarden10DataContext>();
        //    ctx.Stub(x => x.CWS_Galleriess).Return(new List<ICWS_Galleries>
        //    {
        //        gallery
        //    });

        //    var presenter = new ListGalleriesPresenter(view, ctx, contentService);

        //    //Act
        //    view.Raise(x => x.Load += null, null, null);
        //    presenter.ReleaseView();

        //    //Assert
        //    contentService.AssertWasCalled(x => x.GetCurrent());
        //    ctx.AssertWasCalled(x => x.CWS_Galleriess);
        //    node.AssertWasCalled(x => x.Id);
        //    gallery.AssertWasCalled(x => x.Id);
        //    gallery.AssertWasCalled(x => x.CWS_Gallerys);
        //    Assert.IsNotNull(view.Model.PhotoGalleries);
        //}
    }
}
