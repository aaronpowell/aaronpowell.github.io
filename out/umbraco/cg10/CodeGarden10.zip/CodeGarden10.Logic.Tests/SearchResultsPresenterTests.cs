﻿using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using CodeGarden10.Logic.Presenters;
using CodeGarden10.Logic.Views;
using CodeGarden10.Logic.Views.Models;
using Examine;
using Examine.Providers;
using Examine.SearchCriteria;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Rhino.Mocks;

namespace CodeGarden10.Logic.Tests
{
    [TestClass]
    public class SearchResultsPresenterTests
    {
        [TestMethod]
        public void SearchResultsPresenterTests_No_Results_Empty_ResultSet()
        {
            //Arrange
            var view = MockRepository.GenerateStub<ISearchResultsView>();
            view.Model = new SearchResultsModel();
            var searcher = MockRepository.GenerateStub<BaseSearchProvider>();

            var presenter = new SearchResultsPresenter(view, searcher);

            var httpContext = MockRepository.GenerateStub<HttpContextBase>();
            var httpRequest = MockRepository.GenerateStub<HttpRequestBase>();
            httpRequest.Stub(x => x.QueryString).Return(new NameValueCollection());
            httpRequest.QueryString.Add("search", string.Empty);
            httpContext.Stub(x => x.Request).Return(httpRequest);

            presenter.HttpContext = httpContext;
            
            //Act
            view.Raise(x => x.Load += null, null, null);
            presenter.ReleaseView();

            //Assert
            Assert.IsNotNull(view.Model.SearchResults);
            Assert.AreEqual(0, view.Model.SearchResults.Count());

            httpRequest.AssertWasCalled(x => x.QueryString);
            view.AssertWasNotCalled(x => x.ResultsPerPage);
            searcher.AssertWasNotCalled(x => x.CreateSearchCriteria());
        }

        [TestMethod]
        public void SearchResultsPresenterTests_Search_Parameter_Goes_To_Examine()
        {
            //Arrange
            var view = MockRepository.GenerateStub<ISearchResultsView>();
            view.Model = new SearchResultsModel();
            var searcher = MockRepository.GenerateMock<BaseSearchProvider>();
            var sc = MockRepository.GenerateMock<ISearchCriteria>();
            searcher.Expect(x => x.CreateSearchCriteria())
                .Return(sc);
            var operation = MockRepository.GenerateMock<IBooleanOperation>();
            sc.Expect(x => x.GroupedOr(Arg<IEnumerable<string>>.Is.Anything, Arg<string[]>.Is.Anything)).Return(operation);
            operation.Expect(x => x.Compile()).Return(sc);

            var results = MockRepository.GenerateStub<ISearchResults>();
            searcher.Expect(x => x.Search(Arg<ISearchCriteria>.Is.Equal(sc))).Return(results);

            var presenter = new SearchResultsPresenter(view, searcher);

            var httpContext = MockRepository.GenerateStub<HttpContextBase>();
            var httpRequest = MockRepository.GenerateStub<HttpRequestBase>();
            httpRequest.Stub(x => x.QueryString).Return(new NameValueCollection());
            string searchTerm = "hello-world!";
            httpRequest.QueryString.Add("search", searchTerm);
            httpContext.Stub(x => x.Request).Return(httpRequest);

            presenter.HttpContext = httpContext;

            //Act
            view.Raise(x => x.Load += null, null, null);
            presenter.ReleaseView();

            //Assert
            searcher.VerifyAllExpectations();
            sc.VerifyAllExpectations();
            operation.VerifyAllExpectations();

        }
    }
}
