﻿using System.Net.Mail;
using CodeGarden10.Logic.Presenters;
using CodeGarden10.Logic.Services;
using CodeGarden10.Logic.Views;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Rhino.Mocks;
using TheFarm.Snapshot.Abstractions.Models;
using TheFarm.Snapshot.Abstractions.Services;

namespace CodeGarden10.Logic.Tests
{
    [TestClass]
    public class ContactFormPresenterTests
    {
        [TestMethod]
        public void ContactFormPresenterTests_View_Load_Sets_Model_Data()
        {
            //Arrange
            var view = MockRepository.GenerateStub<IContactFormView>();
            view.Stub(x => x.IsValid).Return(false);

            var mailService = MockRepository.GenerateStub<IMailService>();

            var contentService = MockRepository.GenerateStub<IContentService>();
            INode node = MockRepository.GenerateStub<INode>();
            node.Stub(x => x.NodeName).Return("Contact");
            contentService.Stub(x => x.GetCurrent()).Return(node);

            var presenter = new ContactFormPresenter(view, mailService, contentService);

            //Act
            view.Raise(x => x.Load += null, null, null);
            presenter.ReleaseView();

            //Assert
            Assert.AreEqual("Contact", view.Model.NodeName);
        }

        [TestMethod]
        public void ContactFormPresenterTests_Invalid_View_Does_Nothin()
        {
            //Arrange
            var view = MockRepository.GenerateStub<IContactFormView>();
            view.Stub(x => x.IsValid).Return(false);

            var mailService = MockRepository.GenerateStub<IMailService>();

            var contentService = MockRepository.GenerateStub<IContentService>();

            var presenter = new ContactFormPresenter(view, mailService, contentService);

            //Act
            view.Raise(x => x.Submit += null, null, null);
            presenter.ReleaseView();

            //Assert
            view.AssertWasCalled(x => x.IsValid);
            mailService.AssertWasNotCalled(x => x.Send(Arg<MailMessage>.Is.Anything, Arg<bool>.Is.Anything));
        }

        [TestMethod]
        public void ContactFormPresenterTests_MailService_Exception_Handled()
        {
            //Arrange
            var view = MockRepository.GenerateStub<IContactFormView>();
            view.Stub(x => x.IsValid).Return(true);
            view.EmailBody = string.Empty;
            view.EmailTo = "me@aaron-powell.com";

            var mailService = MockRepository.GenerateStub<IMailService>();
            mailService.Expect(x => x.Send(Arg<MailMessage>.Is.Anything, Arg<bool>.Is.Anything)).Throw(new SmtpException());

            var contentService = MockRepository.GenerateStub<IContentService>();

            var presenter = new ContactFormPresenter(view, mailService, contentService);

            var args = new ContactUsEventArgs()
            {
                Email = "me@aaron-powell.com"
            };

            //Act
            view.Raise(x => x.Submit += null, null, args);
            presenter.ReleaseView();

            //Assert
            view.AssertWasCalled(x => x.IsValid);
            view.AssertWasCalled(x => x.EmailSendingFailure(Arg<string>.Is.Anything));
            view.AssertWasNotCalled(x => x.EmailSent());
            mailService.AssertWasCalled(x => x.Send(Arg<MailMessage>.Is.Anything, Arg<bool>.Is.Anything));
        }

        [TestMethod]
        public void ContactFormPresenterTests_Email_Sent_Method_Called()
        {
            //Arrange
            var view = MockRepository.GenerateStub<IContactFormView>();
            view.Stub(x => x.IsValid).Return(true);
            view.EmailBody = string.Empty;
            view.EmailTo = "me@aaron-powell.com";
            view.EmailReplyBody = string.Empty;
            view.EmailReplyFrom = "me@aaron-powell.com";

            var mailService = MockRepository.GenerateStub<IMailService>();

            var contentService = MockRepository.GenerateStub<IContentService>();

            var presenter = new ContactFormPresenter(view, mailService, contentService);

            var args = new ContactUsEventArgs()
            {
                Email = "me@aaron-powell.com"
            };

            //Act
            view.Raise(x => x.Submit += null, null, args);
            presenter.ReleaseView();

            //Assert
            view.AssertWasCalled(x => x.IsValid);
            view.AssertWasNotCalled(x => x.EmailSendingFailure(Arg<string>.Is.Anything));
            view.AssertWasCalled(x => x.EmailSent());
            mailService.AssertWasCalled(x => x.Send(Arg<MailMessage>.Is.Anything, Arg<bool>.Is.Anything), options => options.Repeat.Twice());
        }
    }
}
