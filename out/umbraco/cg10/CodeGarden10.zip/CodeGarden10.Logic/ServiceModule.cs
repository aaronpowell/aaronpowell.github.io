﻿using Autofac;
using CodeGarden10.Logic.Services;
using Examine;
using Examine.Providers;

namespace CodeGarden10.Logic
{
    public class ServiceModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);

            builder.RegisterType<MailService>()
                .As<IMailService>()
                .InstancePerLifetimeScope();

            builder.RegisterType<CodeGarden10DataContext>()
                .As<ICodeGarden10DataContext>()
                .InstancePerLifetimeScope();

            builder.Register<BaseSearchProvider>(x => ExamineManager.Instance.DefaultSearchProvider)
                .SingleInstance();
        }
    }
}
