﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using WebFormsMvp;
using CodeGarden10.Logic.Views.Models;

namespace CodeGarden10.Logic.Views
{
    public interface IListGalleriesView : IView<ListGalleriesModel>
    {
        int PageId { get; }
    }
}
