﻿using WebFormsMvp;
using CodeGarden10.Logic.Views.Models;

namespace CodeGarden10.Logic.Views
{
    public interface ISearchResultsView : IView<SearchResultsModel>
    {
        int ResultsPerPage { get; set; }
    }
}
