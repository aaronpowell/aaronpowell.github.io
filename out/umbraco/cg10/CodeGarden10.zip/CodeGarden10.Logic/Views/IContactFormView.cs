﻿using System;
using WebFormsMvp;
using WebFormsMvp.Contrib.Views;
using CodeGarden10.Logic.Views.Models;

namespace CodeGarden10.Logic.Views
{
    public interface IContactFormView : IView<PageModel>, ISubmittable<ContactUsEventArgs>, IValidatable
    {
       string EmailTo { get; set; }
       string EmailSubject { get; set; }
       string EmailBody { get; set; }
       string EmailReplyFrom { get; set; }
       string EmailReplySubject { get; set; }
       string EmailReplyBody { get; set; }
       string FormHeader { get; set; }
       string FormText { get; set; }
       string ThankYouHeaderText { get; set; }
       string ThankYouMessageText { get; set; }
       bool EnableSSL { get; set; }

       void EmailSendingFailure(string p);

       void EmailSent();
    }

    public class ContactUsEventArgs : EventArgs
    {
        public string Name { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Email { get; set; }
        public string Enquiry { get; set; }
    }
}
