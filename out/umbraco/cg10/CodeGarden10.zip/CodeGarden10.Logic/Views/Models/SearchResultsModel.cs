﻿using System.Collections.Generic;
using Examine;

namespace CodeGarden10.Logic.Views.Models
{
    public class SearchResultsModel
    {
        public string SearchTerm { get; set; }
        public int TotalResults { get; set; }
        public IEnumerable<SearchResult> SearchResults { get; set; }
    }
}
