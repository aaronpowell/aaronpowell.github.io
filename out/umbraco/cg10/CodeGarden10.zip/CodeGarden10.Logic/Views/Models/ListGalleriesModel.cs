﻿using System.Collections.Generic;
using CodeGarden10.Logic.Services;

namespace CodeGarden10.Logic.Views.Models
{
    public class ListGalleriesModel
    {
        public IEnumerable<ICWS_Gallery> PhotoGalleries { get; set; }
    }
}
