﻿
namespace CodeGarden10.Logic.Views.Models
{
    public class PageModel
    {
        public string NodeName { get; set; }
    }
}
