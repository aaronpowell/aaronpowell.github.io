﻿using System;
using System.Net.Mail;
using CodeGarden10.Logic.Services;
using CodeGarden10.Logic.Views;
using WebFormsMvp;
using TheFarm.Snapshot.Abstractions.Services;

namespace CodeGarden10.Logic.Presenters
{
    public class ContactFormPresenter : Presenter<IContactFormView>
    {
        private IMailService mailService;
        private IContentService contentService;

        public ContactFormPresenter(IContactFormView view, IMailService mailService, IContentService contentService)
            : base(view)
        {
            this.mailService = mailService;
            this.contentService = contentService;

            this.View.Load += new EventHandler(View_Load);
            this.View.Submit += new EventHandler<ContactUsEventArgs>(View_Submit);
        }

        void View_Load(object sender, EventArgs e)
        {
            var page = this.contentService.GetCurrent();

            this.View.Model.NodeName = page.NodeName;
        }

        void View_Submit(object sender, ContactUsEventArgs e)
        {
            if (this.View.IsValid)
            {
                var mm = new MailMessage();
                
                mm.From = new MailAddress(e.Email);
                mm.Body = this.View.EmailBody;
                mm.Body = mm.Body
                    .Replace("[Name]", e.Name)
                    .Replace("[AddressLine1]", e.Address1)
                    .Replace("[AddressLine2]", e.Address2)
                    .Replace("[Email]", e.Email)
                    .Replace("[Message]", e.Enquiry)
                    .Replace("[Time]", DateTime.Now.ToString("HH:mm:ss"))
                    .Replace("[Date]", DateTime.Now.ToString("dd/MM/yyyy"));
                mm.Subject = this.View.EmailSubject;
                mm.To.Add(this.View.EmailTo);

                try
                {
                    this.mailService.Send(mm, this.View.EnableSSL);
                }
                catch (SmtpException ex)
                {
                    this.View.EmailSendingFailure(ex.ToString());
                    return;
                }

                mm = new MailMessage();

                mm.From = new MailAddress(this.View.EmailReplyFrom);
                mm.Body = this.View.EmailReplyBody;
                mm.Body = mm.Body
                    .Replace("[Name]", e.Name)
                    .Replace("[AddressLine1]", e.Address1)
                    .Replace("[AddressLine2]", e.Address2)
                    .Replace("[Email]", e.Email)
                    .Replace("[Message]", e.Enquiry)
                    .Replace("[Time]", DateTime.Now.ToString("HH:mm:ss"))
                    .Replace("[Date]", DateTime.Now.ToString("dd/MM/yyyy"));
                mm.Subject = this.View.EmailReplySubject;
                mm.To.Add(e.Email);

                try
                {
                    this.mailService.Send(mm, this.View.EnableSSL);
                }
                catch (SmtpException ex)
                {
                    this.View.EmailSendingFailure(ex.ToString());
                    return;
                }

                this.View.EmailSent();
            }
        }

        public override void ReleaseView()
        {
            this.View.Load -= new EventHandler(View_Load);
            this.View.Submit -= new EventHandler<ContactUsEventArgs>(View_Submit);
        }
    }
}
