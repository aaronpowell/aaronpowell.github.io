﻿using System;
using System.Collections.Generic;
using System.Linq;
using CodeGarden10.Logic.Views;
using Examine;
using Examine.Providers;
using WebFormsMvp;

namespace CodeGarden10.Logic.Presenters
{
    public class SearchResultsPresenter : Presenter<ISearchResultsView>
    {
        private BaseSearchProvider searcher;

        public SearchResultsPresenter(ISearchResultsView view, BaseSearchProvider searcher)
            : base(view)
        {
            this.View.Load += View_Load;
            this.searcher = searcher;
        }

        void View_Load(object sender, EventArgs e)
        {
            string searchTerm = Request.QueryString["search"];
            if (string.IsNullOrEmpty(searchTerm))
            {
                this.View.Model.SearchResults = new List<SearchResult>();
            }
            else
            {
                var sc = searcher.CreateSearchCriteria();
                sc = sc
                    .GroupedOr(new[] { "nodeName", "bodyText" }, searchTerm)
                    .Compile();

                var results = searcher.Search(sc);

                this.View.Model.SearchResults = results.Take(this.View.ResultsPerPage);
                this.View.Model.SearchTerm = searchTerm;
                this.View.Model.TotalResults = results.TotalItemCount;
            }
        }

        public override void ReleaseView()
        {
            this.View.Load -= View_Load;
        }
    }
}
