﻿using System.Linq;
using WebFormsMvp;
using CodeGarden10.Logic.Services;
using CodeGarden10.Logic.Views;
using umbraco.Linq.Core;
namespace CodeGarden10.Logic.Presenters
{
    public class ListGalleriesPresenter : Presenter<IListGalleriesView>
    {
        private ICodeGarden10DataContext ctx;

        public ListGalleriesPresenter(IListGalleriesView view, ICodeGarden10DataContext ctx)
            : base(view)
        {
            this.View.Load += new System.EventHandler(View_Load);
            this.ctx = ctx;
        }

        void View_Load(object sender, System.EventArgs e)
        {
            var currentPageId = this.View.PageId;

            var current = (from g in this.ctx.CWS_Galleriess
                           where g.Id == currentPageId
                           select g).First();

            var sortOrder = current.SortOrder;

            if (sortOrder == "ascending")
            {
                switch (current.SortBy)
                {
                    case "sortOrder":
                        this.View.Model.PhotoGalleries = from gallery in current.CWS_Gallerys
                                              orderby ((IDocTypeBase)gallery).SortOrder
                                              select gallery;
                        break;

                    case "updateDate":
                        this.View.Model.PhotoGalleries = from gallery in current.CWS_Gallerys
                                              orderby gallery.UpdateDate
                                              select gallery;
                        break;

                    default:
                        this.View.Model.PhotoGalleries = from gallery in current.CWS_Gallerys
                                              orderby gallery.CreateDate
                                              select gallery;
                        break;
                }
            }
            else
            {
                switch (current.SortBy)
                {
                    case "sortOrder":
                        this.View.Model.PhotoGalleries = from gallery in current.CWS_Gallerys
                                              orderby ((IDocTypeBase)gallery).SortOrder descending
                                              select gallery;
                        break;

                    case "updateDate":
                        this.View.Model.PhotoGalleries = from gallery in current.CWS_Gallerys
                                              orderby gallery.UpdateDate descending
                                              select gallery;
                        break;

                    default:
                        this.View.Model.PhotoGalleries = from gallery in current.CWS_Gallerys
                                              orderby gallery.CreateDate descending
                                              select gallery;
                        break;
                }
            }
        }


        public override void ReleaseView()
        {
            
        }
    }
}