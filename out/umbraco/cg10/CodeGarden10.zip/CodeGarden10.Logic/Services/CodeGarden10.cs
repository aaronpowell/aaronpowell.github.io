using System;
using System.Linq;
using umbraco.Linq.Core;
using System.Collections.Generic;

namespace CodeGarden10.Logic.Services
{
    public partial class CodeGarden10DataContext : UmbracoDataContext, ICodeGarden10DataContext
    {
        #region Partials
        partial void OnCreated();
        #endregion

        public CodeGarden10DataContext()
            : base()
        {
            OnCreated();
        }

        public CodeGarden10DataContext(UmbracoDataProvider provider)
            : base(provider)
        {
            OnCreated();
        }


        public Tree<CWS_Contact> CWS_Contacts
        {
            get
            {
                return this.LoadTree<CWS_Contact>();
            }
        }
        IEnumerable<ICWS_Contact> ICodeGarden10DataContext.CWS_Contacts
        {
            get
            {
                return this.LoadTree<CWS_Contact>().OfType<ICWS_Contact>();
            }
        }

        public Tree<CWS_EmailAFriend> CWS_EmailAFriends
        {
            get
            {
                return this.LoadTree<CWS_EmailAFriend>();
            }
        }
        IEnumerable<ICWS_EmailAFriend> ICodeGarden10DataContext.CWS_EmailAFriends
        {
            get
            {
                return this.LoadTree<CWS_EmailAFriend>().OfType<ICWS_EmailAFriend>();
            }
        }

        public Tree<CWS_EventItem> CWS_EventItems
        {
            get
            {
                return this.LoadTree<CWS_EventItem>();
            }
        }
        IEnumerable<ICWS_EventItem> ICodeGarden10DataContext.CWS_EventItems
        {
            get
            {
                return this.LoadTree<CWS_EventItem>().OfType<ICWS_EventItem>();
            }
        }

        public Tree<CWS_Galleries> CWS_Galleriess
        {
            get
            {
                return this.LoadTree<CWS_Galleries>();
            }
        }
        IEnumerable<ICWS_Galleries> ICodeGarden10DataContext.CWS_Galleriess
        {
            get
            {
                return this.LoadTree<CWS_Galleries>().OfType<ICWS_Galleries>();
            }
        }

        public Tree<CWS_Gallery> CWS_Gallerys
        {
            get
            {
                return this.LoadTree<CWS_Gallery>();
            }
        }
        IEnumerable<ICWS_Gallery> ICodeGarden10DataContext.CWS_Gallerys
        {
            get
            {
                return this.LoadTree<CWS_Gallery>().OfType<ICWS_Gallery>();
            }
        }

        public Tree<CWS_Home> CWS_Homes
        {
            get
            {
                return this.LoadTree<CWS_Home>();
            }
        }
        IEnumerable<ICWS_Home> ICodeGarden10DataContext.CWS_Homes
        {
            get
            {
                return this.LoadTree<CWS_Home>().OfType<ICWS_Home>();
            }
        }

        public Tree<CWS_NewsEventsList> CWS_NewsEventsLists
        {
            get
            {
                return this.LoadTree<CWS_NewsEventsList>();
            }
        }
        IEnumerable<ICWS_NewsEventsList> ICodeGarden10DataContext.CWS_NewsEventsLists
        {
            get
            {
                return this.LoadTree<CWS_NewsEventsList>().OfType<ICWS_NewsEventsList>();
            }
        }

        public Tree<CWS_NewsItem> CWS_NewsItems
        {
            get
            {
                return this.LoadTree<CWS_NewsItem>();
            }
        }
        IEnumerable<ICWS_NewsItem> ICodeGarden10DataContext.CWS_NewsItems
        {
            get
            {
                return this.LoadTree<CWS_NewsItem>().OfType<ICWS_NewsItem>();
            }
        }

        public Tree<CWS_Photo> CWS_Photos
        {
            get
            {
                return this.LoadTree<CWS_Photo>();
            }
        }
        IEnumerable<ICWS_Photo> ICodeGarden10DataContext.CWS_Photos
        {
            get
            {
                return this.LoadTree<CWS_Photo>().OfType<ICWS_Photo>();
            }
        }

        public Tree<CWS_Textpage> CWS_Textpages
        {
            get
            {
                return this.LoadTree<CWS_Textpage>();
            }
        }
        IEnumerable<ICWS_Textpage> ICodeGarden10DataContext.CWS_Textpages
        {
            get
            {
                return this.LoadTree<CWS_Textpage>().OfType<ICWS_Textpage>();
            }
        }

        public Tree<CWS_TextpageTwoCol> CWS_TextpageTwoCols
        {
            get
            {
                return this.LoadTree<CWS_TextpageTwoCol>();
            }
        }
        IEnumerable<ICWS_TextpageTwoCol> ICodeGarden10DataContext.CWS_TextpageTwoCols
        {
            get
            {
                return this.LoadTree<CWS_TextpageTwoCol>().OfType<ICWS_TextpageTwoCol>();
            }
        }

    }


    /// <summary>
    /// This is the contact form document type for your site.
    /// </summary>
    [UmbracoInfo("CWS_Contact")]
    [System.Runtime.Serialization.DataContractAttribute()]
    [DocType()]
    public partial class CWS_Contact : DocTypeBase, ICWS_Contact
    {
        public CWS_Contact()
        {
        }

        private String _EmailTo;
        /// <summary>
        /// The email address that you want the form to be sent to.
        /// </summary>
        [UmbracoInfo("emailTo", DisplayName = "Email To", Mandatory = true)]
        [Property()]
        public virtual String EmailTo
        {
            get
            {
                return this._EmailTo;
            }
            set
            {
                if ((this._EmailTo != value))
                {
                    this.RaisePropertyChanging();
                    this._EmailTo = value;
                    this.RaisePropertyChanged("EmailTo");
                }
            }
        }
        private String _EmailSubject;
        /// <summary>
        /// The subject of the email that will be sent to you.
        /// </summary>
        [UmbracoInfo("emailSubject", DisplayName = "Email Subject", Mandatory = true)]
        [Property()]
        public virtual String EmailSubject
        {
            get
            {
                return this._EmailSubject;
            }
            set
            {
                if ((this._EmailSubject != value))
                {
                    this.RaisePropertyChanging();
                    this._EmailSubject = value;
                    this.RaisePropertyChanged("EmailSubject");
                }
            }
        }
        private String _EmailBody;
        /// <summary>
        /// Use placeholders [Name], [AddressLine1], [AddressLine2], [Email], [Message], [Time] and [Date]
        /// </summary>
        [UmbracoInfo("emailBody", DisplayName = "Email Message", Mandatory = true)]
        [Property()]
        public virtual String EmailBody
        {
            get
            {
                return this._EmailBody;
            }
            set
            {
                if ((this._EmailBody != value))
                {
                    this.RaisePropertyChanging();
                    this._EmailBody = value;
                    this.RaisePropertyChanged("EmailBody");
                }
            }
        }
        private String _EmailReplyFrom;
        /// <summary>
        /// The email address that you want the automated reply to be sent from.
        /// </summary>
        [UmbracoInfo("emailReplyFrom", DisplayName = "Email Reply From", Mandatory = true)]
        [Property()]
        public virtual String EmailReplyFrom
        {
            get
            {
                return this._EmailReplyFrom;
            }
            set
            {
                if ((this._EmailReplyFrom != value))
                {
                    this.RaisePropertyChanging();
                    this._EmailReplyFrom = value;
                    this.RaisePropertyChanged("EmailReplyFrom");
                }
            }
        }
        private String _EmailReplySubject;
        /// <summary>
        /// The subject of the email that will be sent as the automated reply.
        ///
        /// </summary>
        [UmbracoInfo("emailReplySubject", DisplayName = "Email Reply Subject", Mandatory = false)]
        [Property()]
        public virtual String EmailReplySubject
        {
            get
            {
                return this._EmailReplySubject;
            }
            set
            {
                if ((this._EmailReplySubject != value))
                {
                    this.RaisePropertyChanging();
                    this._EmailReplySubject = value;
                    this.RaisePropertyChanged("EmailReplySubject");
                }
            }
        }
        private String _EmailReplyBody;
        /// <summary>
        /// Use placeholder [Name]
        /// </summary>
        [UmbracoInfo("emailReplyBody", DisplayName = "Email Reply Body", Mandatory = false)]
        [Property()]
        public virtual String EmailReplyBody
        {
            get
            {
                return this._EmailReplyBody;
            }
            set
            {
                if ((this._EmailReplyBody != value))
                {
                    this.RaisePropertyChanging();
                    this._EmailReplyBody = value;
                    this.RaisePropertyChanged("EmailReplyBody");
                }
            }
        }
        private Int32 _EnableSSL;
        /// <summary>
        /// Does your SMTP server require SSL?
        /// </summary>
        [UmbracoInfo("enableSSL", DisplayName = "Enable SSL", Mandatory = false)]
        [Property()]
        public virtual Int32 EnableSSL
        {
            get
            {
                return this._EnableSSL;
            }
            set
            {
                if ((this._EnableSSL != value))
                {
                    this.RaisePropertyChanging();
                    this._EnableSSL = value;
                    this.RaisePropertyChanged("EnableSSL");
                }
            }
        }
        private String _UmbracoUrlName;
        /// <summary>
        /// If you wish to change the URL of the node without changing the node name fill this in.
        ///
        ///eg: warren
        /// </summary>
        [UmbracoInfo("umbracoUrlName", DisplayName = "Umbraco URL Name", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlName
        {
            get
            {
                return this._UmbracoUrlName;
            }
            set
            {
                if ((this._UmbracoUrlName != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlName = value;
                    this.RaisePropertyChanged("UmbracoUrlName");
                }
            }
        }
        private String _UmbracoUrlAlias;
        /// <summary>
        /// Use this to give a node multiple urls.
        ///
        ///eg: home,homepage/another-level
        /// </summary>
        [UmbracoInfo("umbracoUrlAlias", DisplayName = "Umbraco URL Alias", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlAlias
        {
            get
            {
                return this._UmbracoUrlAlias;
            }
            set
            {
                if ((this._UmbracoUrlAlias != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlAlias = value;
                    this.RaisePropertyChanged("UmbracoUrlAlias");
                }
            }
        }
        private String _MetaDescription;
        /// <summary>
        /// Enter the description for the page.
        /// </summary>
        [UmbracoInfo("metaDescription", DisplayName = "Meta Description", Mandatory = false)]
        [Property()]
        public virtual String MetaDescription
        {
            get
            {
                return this._MetaDescription;
            }
            set
            {
                if ((this._MetaDescription != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaDescription = value;
                    this.RaisePropertyChanged("MetaDescription");
                }
            }
        }
        private String _MetaKeywords;
        /// <summary>
        /// Enter a comma seperated list of keywords.
        ///warren, keyword, test
        /// </summary>
        [UmbracoInfo("metaKeywords", DisplayName = "Meta Keywords", Mandatory = false)]
        [Property()]
        public virtual String MetaKeywords
        {
            get
            {
                return this._MetaKeywords;
            }
            set
            {
                if ((this._MetaKeywords != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaKeywords = value;
                    this.RaisePropertyChanged("MetaKeywords");
                }
            }
        }
        private Int32 _UmbracoRedirect;
        /// <summary>
        /// Pick a node you wish to redirect to if the user lands on this node.
        /// </summary>
        [UmbracoInfo("umbracoRedirect", DisplayName = " Umbraco Redirect", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoRedirect
        {
            get
            {
                return this._UmbracoRedirect;
            }
            set
            {
                if ((this._UmbracoRedirect != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoRedirect = value;
                    this.RaisePropertyChanged("UmbracoRedirect");
                }
            }
        }
        private Int32 _UmbracoNaviHide;
        /// <summary>
        /// Use this property if you wish to hide this page in the navigation.
        /// </summary>
        [UmbracoInfo("umbracoNaviHide", DisplayName = "Hide in Navi", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoNaviHide
        {
            get
            {
                return this._UmbracoNaviHide;
            }
            set
            {
                if ((this._UmbracoNaviHide != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoNaviHide = value;
                    this.RaisePropertyChanged("UmbracoNaviHide");
                }
            }
        }
        private String _HeaderText;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("headerText", DisplayName = "Header", Mandatory = false)]
        [Property()]
        public virtual String HeaderText
        {
            get
            {
                return this._HeaderText;
            }
            set
            {
                if ((this._HeaderText != value))
                {
                    this.RaisePropertyChanging();
                    this._HeaderText = value;
                    this.RaisePropertyChanged("HeaderText");
                }
            }
        }
        private String _FormText;
        /// <summary>
        /// This is the text that sits to the left of the contact form.
        /// </summary>
        [UmbracoInfo("formText", DisplayName = "Form Text", Mandatory = false)]
        [Property()]
        public virtual String FormText
        {
            get
            {
                return this._FormText;
            }
            set
            {
                if ((this._FormText != value))
                {
                    this.RaisePropertyChanging();
                    this._FormText = value;
                    this.RaisePropertyChanged("FormText");
                }
            }
        }
        private String _ThankYouHeaderText;
        /// <summary>
        /// This is the header for the thankyou the user will see after sumbitting the contact form.
        /// </summary>
        [UmbracoInfo("thankYouHeaderText", DisplayName = "Thank You Header", Mandatory = true)]
        [Property()]
        public virtual String ThankYouHeaderText
        {
            get
            {
                return this._ThankYouHeaderText;
            }
            set
            {
                if ((this._ThankYouHeaderText != value))
                {
                    this.RaisePropertyChanging();
                    this._ThankYouHeaderText = value;
                    this.RaisePropertyChanged("ThankYouHeaderText");
                }
            }
        }
        private String _ThankYouMessageText;
        /// <summary>
        /// This is the thankyou message that the user will see after submitting your form.
        /// </summary>
        [UmbracoInfo("thankYouMessageText", DisplayName = "Thank You Message", Mandatory = true)]
        [Property()]
        public virtual String ThankYouMessageText
        {
            get
            {
                return this._ThankYouMessageText;
            }
            set
            {
                if ((this._ThankYouMessageText != value))
                {
                    this.RaisePropertyChanging();
                    this._ThankYouMessageText = value;
                    this.RaisePropertyChanged("ThankYouMessageText");
                }
            }
        }

        private AssociationTree<CWS_Textpage> _CWS_Textpages;
        public AssociationTree<CWS_Textpage> CWS_Textpages
        {
            get
            {
                if ((this._CWS_Textpages == null))
                {
                    this._CWS_Textpages = this.ChildrenOfType<CWS_Textpage>();
                }
                return this._CWS_Textpages;
            }
            set
            {
                this._CWS_Textpages = value;
            }
        }

        IEnumerable<ICWS_Textpage> ICWS_Contact.CWS_Textpages
        {
            get
            {
                return this.CWS_Textpages.OfType<ICWS_Textpage>();
            }
        }
    }
    /// <summary>
    /// This is the email a friend form document type for your site.
    /// </summary>
    [UmbracoInfo("CWS_EmailAFriend")]
    [System.Runtime.Serialization.DataContractAttribute()]
    [DocType()]
    public partial class CWS_EmailAFriend : DocTypeBase, ICWS_EmailAFriend
    {
        public CWS_EmailAFriend()
        {
        }

        private String _EmailFrom;
        /// <summary>
        /// The email address that you want the email to be sent from.
        /// </summary>
        [UmbracoInfo("emailFrom", DisplayName = "Email From", Mandatory = true)]
        [Property()]
        public virtual String EmailFrom
        {
            get
            {
                return this._EmailFrom;
            }
            set
            {
                if ((this._EmailFrom != value))
                {
                    this.RaisePropertyChanging();
                    this._EmailFrom = value;
                    this.RaisePropertyChanged("EmailFrom");
                }
            }
        }
        private String _EmailSubjectToFriend;
        /// <summary>
        /// The subject of the email that will be sent to the friend.
        /// </summary>
        [UmbracoInfo("emailSubjectToFriend", DisplayName = "Email Subject to Friend", Mandatory = true)]
        [Property()]
        public virtual String EmailSubjectToFriend
        {
            get
            {
                return this._EmailSubjectToFriend;
            }
            set
            {
                if ((this._EmailSubjectToFriend != value))
                {
                    this.RaisePropertyChanging();
                    this._EmailSubjectToFriend = value;
                    this.RaisePropertyChanged("EmailSubjectToFriend");
                }
            }
        }
        private String _EmailMessageToFriend;
        /// <summary>
        /// Use placeholders [FriendName], [FriendEmail], [YourName], [YourEmail], [Message], [Date], [Time], [URL]
        /// </summary>
        [UmbracoInfo("emailMessageToFriend", DisplayName = "Email Message to Friend", Mandatory = true)]
        [Property()]
        public virtual String EmailMessageToFriend
        {
            get
            {
                return this._EmailMessageToFriend;
            }
            set
            {
                if ((this._EmailMessageToFriend != value))
                {
                    this.RaisePropertyChanging();
                    this._EmailMessageToFriend = value;
                    this.RaisePropertyChanged("EmailMessageToFriend");
                }
            }
        }
        private Int32 _EnableSSL;
        /// <summary>
        /// Does your SMTP server require SSL?
        /// </summary>
        [UmbracoInfo("enableSSL", DisplayName = "Enable SSL", Mandatory = false)]
        [Property()]
        public virtual Int32 EnableSSL
        {
            get
            {
                return this._EnableSSL;
            }
            set
            {
                if ((this._EnableSSL != value))
                {
                    this.RaisePropertyChanging();
                    this._EnableSSL = value;
                    this.RaisePropertyChanged("EnableSSL");
                }
            }
        }
        private String _UmbracoUrlName;
        /// <summary>
        /// If you wish to change the URL of the node without changing the node name fill this in.
        ///
        ///eg: warren
        /// </summary>
        [UmbracoInfo("umbracoUrlName", DisplayName = "Umbraco URL Name", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlName
        {
            get
            {
                return this._UmbracoUrlName;
            }
            set
            {
                if ((this._UmbracoUrlName != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlName = value;
                    this.RaisePropertyChanged("UmbracoUrlName");
                }
            }
        }
        private String _UmbracoUrlAlias;
        /// <summary>
        /// Use this to give a node multiple urls.
        ///
        ///eg: home,homepage/another-level
        /// </summary>
        [UmbracoInfo("umbracoUrlAlias", DisplayName = "Umbraco URL Alias", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlAlias
        {
            get
            {
                return this._UmbracoUrlAlias;
            }
            set
            {
                if ((this._UmbracoUrlAlias != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlAlias = value;
                    this.RaisePropertyChanged("UmbracoUrlAlias");
                }
            }
        }
        private String _MetaDescription;
        /// <summary>
        /// Enter the description for the page.
        /// </summary>
        [UmbracoInfo("metaDescription", DisplayName = "Meta Description", Mandatory = false)]
        [Property()]
        public virtual String MetaDescription
        {
            get
            {
                return this._MetaDescription;
            }
            set
            {
                if ((this._MetaDescription != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaDescription = value;
                    this.RaisePropertyChanged("MetaDescription");
                }
            }
        }
        private String _MetaKeywords;
        /// <summary>
        /// Enter a comma seperated list of keywords.
        ///warren, keyword, test
        /// </summary>
        [UmbracoInfo("metaKeywords", DisplayName = "Meta Keywords", Mandatory = false)]
        [Property()]
        public virtual String MetaKeywords
        {
            get
            {
                return this._MetaKeywords;
            }
            set
            {
                if ((this._MetaKeywords != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaKeywords = value;
                    this.RaisePropertyChanged("MetaKeywords");
                }
            }
        }
        private Int32 _UmbracoRedirect;
        /// <summary>
        /// Pick a node you wish to redirect to if the user lands on this node.
        /// </summary>
        [UmbracoInfo("umbracoRedirect", DisplayName = " Umbraco Redirect", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoRedirect
        {
            get
            {
                return this._UmbracoRedirect;
            }
            set
            {
                if ((this._UmbracoRedirect != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoRedirect = value;
                    this.RaisePropertyChanged("UmbracoRedirect");
                }
            }
        }
        private Int32 _UmbracoNaviHide;
        /// <summary>
        /// Use this property if you wish to hide this page in the navigation.
        /// </summary>
        [UmbracoInfo("umbracoNaviHide", DisplayName = "Hide in Navi", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoNaviHide
        {
            get
            {
                return this._UmbracoNaviHide;
            }
            set
            {
                if ((this._UmbracoNaviHide != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoNaviHide = value;
                    this.RaisePropertyChanged("UmbracoNaviHide");
                }
            }
        }
        private String _HeaderText;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("headerText", DisplayName = "Header", Mandatory = false)]
        [Property()]
        public virtual String HeaderText
        {
            get
            {
                return this._HeaderText;
            }
            set
            {
                if ((this._HeaderText != value))
                {
                    this.RaisePropertyChanging();
                    this._HeaderText = value;
                    this.RaisePropertyChanged("HeaderText");
                }
            }
        }
        private String _ThankYouHeaderText;
        /// <summary>
        /// This is the header for the thankyou the user will see after sumbitting the contact form.
        /// </summary>
        [UmbracoInfo("thankYouHeaderText", DisplayName = "Thank You Header", Mandatory = true)]
        [Property()]
        public virtual String ThankYouHeaderText
        {
            get
            {
                return this._ThankYouHeaderText;
            }
            set
            {
                if ((this._ThankYouHeaderText != value))
                {
                    this.RaisePropertyChanging();
                    this._ThankYouHeaderText = value;
                    this.RaisePropertyChanged("ThankYouHeaderText");
                }
            }
        }
        private String _ThankYouMessageText;
        /// <summary>
        /// This is the thankyou message that the user will see after submitting your form.
        /// </summary>
        [UmbracoInfo("thankYouMessageText", DisplayName = "Thank You Text", Mandatory = true)]
        [Property()]
        public virtual String ThankYouMessageText
        {
            get
            {
                return this._ThankYouMessageText;
            }
            set
            {
                if ((this._ThankYouMessageText != value))
                {
                    this.RaisePropertyChanging();
                    this._ThankYouMessageText = value;
                    this.RaisePropertyChanged("ThankYouMessageText");
                }
            }
        }

        private AssociationTree<CWS_Textpage> _CWS_Textpages;
        public AssociationTree<CWS_Textpage> CWS_Textpages
        {
            get
            {
                if ((this._CWS_Textpages == null))
                {
                    this._CWS_Textpages = this.ChildrenOfType<CWS_Textpage>();
                }
                return this._CWS_Textpages;
            }
            set
            {
                this._CWS_Textpages = value;
            }
        }

        IEnumerable<ICWS_Textpage> ICWS_EmailAFriend.CWS_Textpages
        {
            get
            {
                return this.CWS_Textpages.OfType<ICWS_Textpage>();
            }
        }
    }
    /// <summary>
    /// This is the event document type for your site and lives beneath the News & Events List document type.
    /// </summary>
    [UmbracoInfo("CWS_EventItem")]
    [System.Runtime.Serialization.DataContractAttribute()]
    [DocType()]
    public partial class CWS_EventItem : DocTypeBase, ICWS_EventItem
    {
        public CWS_EventItem()
        {
        }

        private DateTime _EventDate;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("eventDate", DisplayName = "Date", Mandatory = false)]
        [Property()]
        public virtual DateTime EventDate
        {
            get
            {
                return this._EventDate;
            }
            set
            {
                if ((this._EventDate != value))
                {
                    this.RaisePropertyChanging();
                    this._EventDate = value;
                    this.RaisePropertyChanged("EventDate");
                }
            }
        }
        private String _BodyText;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("bodyText", DisplayName = "Text", Mandatory = false)]
        [Property()]
        public virtual String BodyText
        {
            get
            {
                return this._BodyText;
            }
            set
            {
                if ((this._BodyText != value))
                {
                    this.RaisePropertyChanging();
                    this._BodyText = value;
                    this.RaisePropertyChanged("BodyText");
                }
            }
        }
        private String _ArticlePhoto;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("articlePhoto", DisplayName = "Photo", Mandatory = false)]
        [Property()]
        public virtual String ArticlePhoto
        {
            get
            {
                return this._ArticlePhoto;
            }
            set
            {
                if ((this._ArticlePhoto != value))
                {
                    this.RaisePropertyChanging();
                    this._ArticlePhoto = value;
                    this.RaisePropertyChanged("ArticlePhoto");
                }
            }
        }
        private String _UmbracoUrlName;
        /// <summary>
        /// If you wish to change the URL of the node without changing the node name fill this in.
        ///
        ///eg: warren
        /// </summary>
        [UmbracoInfo("umbracoUrlName", DisplayName = "Umbraco URL Name", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlName
        {
            get
            {
                return this._UmbracoUrlName;
            }
            set
            {
                if ((this._UmbracoUrlName != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlName = value;
                    this.RaisePropertyChanged("UmbracoUrlName");
                }
            }
        }
        private String _UmbracoUrlAlias;
        /// <summary>
        /// Use this to give a node multiple urls.
        ///
        ///eg: home,homepage/another-level
        /// </summary>
        [UmbracoInfo("umbracoUrlAlias", DisplayName = "Umbraco URL Alias", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlAlias
        {
            get
            {
                return this._UmbracoUrlAlias;
            }
            set
            {
                if ((this._UmbracoUrlAlias != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlAlias = value;
                    this.RaisePropertyChanged("UmbracoUrlAlias");
                }
            }
        }
        private String _MetaDescription;
        /// <summary>
        /// Enter the description for the page.
        /// </summary>
        [UmbracoInfo("metaDescription", DisplayName = "Meta Description", Mandatory = false)]
        [Property()]
        public virtual String MetaDescription
        {
            get
            {
                return this._MetaDescription;
            }
            set
            {
                if ((this._MetaDescription != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaDescription = value;
                    this.RaisePropertyChanged("MetaDescription");
                }
            }
        }
        private String _MetaKeywords;
        /// <summary>
        /// Enter a comma seperated list of keywords.
        ///warren, keyword, test
        /// </summary>
        [UmbracoInfo("metaKeywords", DisplayName = "Meta Keywords", Mandatory = false)]
        [Property()]
        public virtual String MetaKeywords
        {
            get
            {
                return this._MetaKeywords;
            }
            set
            {
                if ((this._MetaKeywords != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaKeywords = value;
                    this.RaisePropertyChanged("MetaKeywords");
                }
            }
        }
        private Int32 _UmbracoRedirect;
        /// <summary>
        /// Pick a node you wish to redirect to if the user lands on this node.
        /// </summary>
        [UmbracoInfo("umbracoRedirect", DisplayName = " Umbraco Redirect", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoRedirect
        {
            get
            {
                return this._UmbracoRedirect;
            }
            set
            {
                if ((this._UmbracoRedirect != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoRedirect = value;
                    this.RaisePropertyChanged("UmbracoRedirect");
                }
            }
        }
        private Int32 _UmbracoNaviHide;
        /// <summary>
        /// Use this property if you wish to hide this page in the navigation.
        /// </summary>
        [UmbracoInfo("umbracoNaviHide", DisplayName = "Hide in Navi", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoNaviHide
        {
            get
            {
                return this._UmbracoNaviHide;
            }
            set
            {
                if ((this._UmbracoNaviHide != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoNaviHide = value;
                    this.RaisePropertyChanged("UmbracoNaviHide");
                }
            }
        }


    }
    /// <summary>
    /// This is the Galleries document type for your site which stores the Gallery document type as children.
    /// </summary>
    [UmbracoInfo("CWS_Galleries")]
    [System.Runtime.Serialization.DataContractAttribute()]
    [DocType()]
    public partial class CWS_Galleries : DocTypeBase, ICWS_Galleries
    {
        public CWS_Galleries()
        {
        }

        private String _UmbracoUrlName;
        /// <summary>
        /// If you wish to change the URL of the node without changing the node name fill this in.
        ///
        ///eg: warren
        /// </summary>
        [UmbracoInfo("umbracoUrlName", DisplayName = "Umbraco URL Name", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlName
        {
            get
            {
                return this._UmbracoUrlName;
            }
            set
            {
                if ((this._UmbracoUrlName != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlName = value;
                    this.RaisePropertyChanged("UmbracoUrlName");
                }
            }
        }
        private String _UmbracoUrlAlias;
        /// <summary>
        /// Use this to give a node multiple urls.
        ///
        ///eg: home,homepage/another-level
        /// </summary>
        [UmbracoInfo("umbracoUrlAlias", DisplayName = "Umbraco URL Alias", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlAlias
        {
            get
            {
                return this._UmbracoUrlAlias;
            }
            set
            {
                if ((this._UmbracoUrlAlias != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlAlias = value;
                    this.RaisePropertyChanged("UmbracoUrlAlias");
                }
            }
        }
        private String _MetaDescription;
        /// <summary>
        /// Enter the description for the page.
        /// </summary>
        [UmbracoInfo("metaDescription", DisplayName = "Meta Description", Mandatory = false)]
        [Property()]
        public virtual String MetaDescription
        {
            get
            {
                return this._MetaDescription;
            }
            set
            {
                if ((this._MetaDescription != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaDescription = value;
                    this.RaisePropertyChanged("MetaDescription");
                }
            }
        }
        private String _MetaKeywords;
        /// <summary>
        /// Enter a comma seperated list of keywords.
        ///warren, keyword, test
        /// </summary>
        [UmbracoInfo("metaKeywords", DisplayName = "Meta Keywords", Mandatory = false)]
        [Property()]
        public virtual String MetaKeywords
        {
            get
            {
                return this._MetaKeywords;
            }
            set
            {
                if ((this._MetaKeywords != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaKeywords = value;
                    this.RaisePropertyChanged("MetaKeywords");
                }
            }
        }
        private Int32 _UmbracoRedirect;
        /// <summary>
        /// Pick a node you wish to redirect to if the user lands on this node.
        /// </summary>
        [UmbracoInfo("umbracoRedirect", DisplayName = " Umbraco Redirect", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoRedirect
        {
            get
            {
                return this._UmbracoRedirect;
            }
            set
            {
                if ((this._UmbracoRedirect != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoRedirect = value;
                    this.RaisePropertyChanged("UmbracoRedirect");
                }
            }
        }
        private Int32 _UmbracoNaviHide;
        /// <summary>
        /// Use this property if you wish to hide this page in the navigation.
        /// </summary>
        [UmbracoInfo("umbracoNaviHide", DisplayName = "Hide in Navi", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoNaviHide
        {
            get
            {
                return this._UmbracoNaviHide;
            }
            set
            {
                if ((this._UmbracoNaviHide != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoNaviHide = value;
                    this.RaisePropertyChanged("UmbracoNaviHide");
                }
            }
        }
        private String _HeaderText;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("headerText", DisplayName = "Header", Mandatory = false)]
        [Property()]
        public virtual String HeaderText
        {
            get
            {
                return this._HeaderText;
            }
            set
            {
                if ((this._HeaderText != value))
                {
                    this.RaisePropertyChanging();
                    this._HeaderText = value;
                    this.RaisePropertyChanged("HeaderText");
                }
            }
        }
        private String _SortBy;
        /// <summary>
        /// Choose how you want to sort the child items.
        /// </summary>
        [UmbracoInfo("sortBy", DisplayName = "Sort By", Mandatory = true)]
        [Property()]
        public virtual String SortBy
        {
            get
            {
                return this._SortBy;
            }
            set
            {
                if ((this._SortBy != value))
                {
                    this.RaisePropertyChanging();
                    this._SortBy = value;
                    this.RaisePropertyChanged("SortBy");
                }
            }
        }
        private String _SortOrder;
        /// <summary>
        /// Choose how you want to sort the child items.
        /// </summary>
        [UmbracoInfo("sortOrder", DisplayName = "Sort Order", Mandatory = true)]
        [Property()]
        public virtual String SortOrder
        {
            get
            {
                return this._SortOrder;
            }
            set
            {
                if ((this._SortOrder != value))
                {
                    this.RaisePropertyChanging();
                    this._SortOrder = value;
                    this.RaisePropertyChanged("SortOrder");
                }
            }
        }

        private AssociationTree<CWS_Gallery> _CWS_Gallerys;
        public AssociationTree<CWS_Gallery> CWS_Gallerys
        {
            get
            {
                if ((this._CWS_Gallerys == null))
                {
                    this._CWS_Gallerys = this.ChildrenOfType<CWS_Gallery>();
                }
                return this._CWS_Gallerys;
            }
            set
            {
                this._CWS_Gallerys = value;
            }
        }

        IEnumerable<ICWS_Gallery> ICWS_Galleries.CWS_Gallerys
        {
            get
            {
                return this.CWS_Gallerys.OfType<ICWS_Gallery>();
            }
        }
    }
    /// <summary>
    /// This is the gallery document type which stores the Photo document type as children.
    /// </summary>
    [UmbracoInfo("CWS_Gallery")]
    [System.Runtime.Serialization.DataContractAttribute()]
    [DocType()]
    public partial class CWS_Gallery : DocTypeBase, ICWS_Gallery
    {
        public CWS_Gallery()
        {
        }

        private String _UmbracoUrlName;
        /// <summary>
        /// If you wish to change the URL of the node without changing the node name fill this in.
        ///
        ///eg: warren
        /// </summary>
        [UmbracoInfo("umbracoUrlName", DisplayName = "Umbraco URL Name", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlName
        {
            get
            {
                return this._UmbracoUrlName;
            }
            set
            {
                if ((this._UmbracoUrlName != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlName = value;
                    this.RaisePropertyChanged("UmbracoUrlName");
                }
            }
        }
        private String _UmbracoUrlAlias;
        /// <summary>
        /// Use this to give a node multiple urls.
        ///
        ///eg: home,homepage/another-level
        /// </summary>
        [UmbracoInfo("umbracoUrlAlias", DisplayName = "Umbraco URL Alias", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlAlias
        {
            get
            {
                return this._UmbracoUrlAlias;
            }
            set
            {
                if ((this._UmbracoUrlAlias != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlAlias = value;
                    this.RaisePropertyChanged("UmbracoUrlAlias");
                }
            }
        }
        private String _MetaDescription;
        /// <summary>
        /// Enter the description for the page.
        /// </summary>
        [UmbracoInfo("metaDescription", DisplayName = "Meta Description", Mandatory = false)]
        [Property()]
        public virtual String MetaDescription
        {
            get
            {
                return this._MetaDescription;
            }
            set
            {
                if ((this._MetaDescription != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaDescription = value;
                    this.RaisePropertyChanged("MetaDescription");
                }
            }
        }
        private String _MetaKeywords;
        /// <summary>
        /// Enter a comma seperated list of keywords.
        ///warren, keyword, test
        /// </summary>
        [UmbracoInfo("metaKeywords", DisplayName = "Meta Keywords", Mandatory = false)]
        [Property()]
        public virtual String MetaKeywords
        {
            get
            {
                return this._MetaKeywords;
            }
            set
            {
                if ((this._MetaKeywords != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaKeywords = value;
                    this.RaisePropertyChanged("MetaKeywords");
                }
            }
        }
        private Int32 _UmbracoRedirect;
        /// <summary>
        /// Pick a node you wish to redirect to if the user lands on this node.
        /// </summary>
        [UmbracoInfo("umbracoRedirect", DisplayName = " Umbraco Redirect", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoRedirect
        {
            get
            {
                return this._UmbracoRedirect;
            }
            set
            {
                if ((this._UmbracoRedirect != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoRedirect = value;
                    this.RaisePropertyChanged("UmbracoRedirect");
                }
            }
        }
        private Int32 _UmbracoNaviHide;
        /// <summary>
        /// Use this property if you wish to hide this page in the navigation.
        /// </summary>
        [UmbracoInfo("umbracoNaviHide", DisplayName = "Hide in Navi", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoNaviHide
        {
            get
            {
                return this._UmbracoNaviHide;
            }
            set
            {
                if ((this._UmbracoNaviHide != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoNaviHide = value;
                    this.RaisePropertyChanged("UmbracoNaviHide");
                }
            }
        }
        private String _HeaderText;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("headerText", DisplayName = "Header", Mandatory = false)]
        [Property()]
        public virtual String HeaderText
        {
            get
            {
                return this._HeaderText;
            }
            set
            {
                if ((this._HeaderText != value))
                {
                    this.RaisePropertyChanging();
                    this._HeaderText = value;
                    this.RaisePropertyChanged("HeaderText");
                }
            }
        }
        private String _SortBy;
        /// <summary>
        /// Choose how you want to sort the child items.
        /// </summary>
        [UmbracoInfo("sortBy", DisplayName = "Sort By", Mandatory = true)]
        [Property()]
        public virtual String SortBy
        {
            get
            {
                return this._SortBy;
            }
            set
            {
                if ((this._SortBy != value))
                {
                    this.RaisePropertyChanging();
                    this._SortBy = value;
                    this.RaisePropertyChanged("SortBy");
                }
            }
        }
        private String _SortOrder;
        /// <summary>
        /// Choose how you want to sort the child items.
        /// </summary>
        [UmbracoInfo("sortOrder", DisplayName = "Sort Order", Mandatory = true)]
        [Property()]
        public virtual String SortOrder
        {
            get
            {
                return this._SortOrder;
            }
            set
            {
                if ((this._SortOrder != value))
                {
                    this.RaisePropertyChanging();
                    this._SortOrder = value;
                    this.RaisePropertyChanged("SortOrder");
                }
            }
        }
        private String _GalleryThumbnail;
        /// <summary>
        /// 208px x 108px
        /// </summary>
        [UmbracoInfo("galleryThumbnail", DisplayName = "Thumbnail for Gallery", Mandatory = false)]
        [Property()]
        public virtual String GalleryThumbnail
        {
            get
            {
                return this._GalleryThumbnail;
            }
            set
            {
                if ((this._GalleryThumbnail != value))
                {
                    this.RaisePropertyChanging();
                    this._GalleryThumbnail = value;
                    this.RaisePropertyChanged("GalleryThumbnail");
                }
            }
        }

        private AssociationTree<CWS_Photo> _CWS_Photos;
        public AssociationTree<CWS_Photo> CWS_Photos
        {
            get
            {
                if ((this._CWS_Photos == null))
                {
                    this._CWS_Photos = this.ChildrenOfType<CWS_Photo>();
                }
                return this._CWS_Photos;
            }
            set
            {
                this._CWS_Photos = value;
            }
        }

        IEnumerable<ICWS_Photo> ICWS_Gallery.CWS_Photos
        {
            get
            {
                return this.CWS_Photos.OfType<ICWS_Photo>();
            }
        }
    }
    /// <summary>
    /// This is the homepage document type for your site.
    /// </summary>
    [UmbracoInfo("CWS_Home")]
    [System.Runtime.Serialization.DataContractAttribute()]
    [DocType()]
    public partial class CWS_Home : DocTypeBase, ICWS_Home
    {
        public CWS_Home()
        {
        }

        private String _UmbracoUrlName;
        /// <summary>
        /// If you wish to change the URL of the node without changing the node name fill this in.
        ///
        ///eg: warren
        /// </summary>
        [UmbracoInfo("umbracoUrlName", DisplayName = "Umbraco URL Name", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlName
        {
            get
            {
                return this._UmbracoUrlName;
            }
            set
            {
                if ((this._UmbracoUrlName != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlName = value;
                    this.RaisePropertyChanged("UmbracoUrlName");
                }
            }
        }
        private String _UmbracoUrlAlias;
        /// <summary>
        /// Use this to give a node multiple urls.
        ///
        ///eg: home,homepage/another-level
        /// </summary>
        [UmbracoInfo("umbracoUrlAlias", DisplayName = "Umbraco URL Alias", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlAlias
        {
            get
            {
                return this._UmbracoUrlAlias;
            }
            set
            {
                if ((this._UmbracoUrlAlias != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlAlias = value;
                    this.RaisePropertyChanged("UmbracoUrlAlias");
                }
            }
        }
        private String _MetaDescription;
        /// <summary>
        /// Enter the description for the page.
        /// </summary>
        [UmbracoInfo("metaDescription", DisplayName = "Meta Description", Mandatory = false)]
        [Property()]
        public virtual String MetaDescription
        {
            get
            {
                return this._MetaDescription;
            }
            set
            {
                if ((this._MetaDescription != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaDescription = value;
                    this.RaisePropertyChanged("MetaDescription");
                }
            }
        }
        private String _MetaKeywords;
        /// <summary>
        /// Enter a comma seperated list of keywords.
        ///warren, keyword, test
        /// </summary>
        [UmbracoInfo("metaKeywords", DisplayName = "Meta Keywords", Mandatory = false)]
        [Property()]
        public virtual String MetaKeywords
        {
            get
            {
                return this._MetaKeywords;
            }
            set
            {
                if ((this._MetaKeywords != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaKeywords = value;
                    this.RaisePropertyChanged("MetaKeywords");
                }
            }
        }
        private Int32 _UmbracoRedirect;
        /// <summary>
        /// Pick a node you wish to redirect to if the user lands on this node.
        /// </summary>
        [UmbracoInfo("umbracoRedirect", DisplayName = " Umbraco Redirect", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoRedirect
        {
            get
            {
                return this._UmbracoRedirect;
            }
            set
            {
                if ((this._UmbracoRedirect != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoRedirect = value;
                    this.RaisePropertyChanged("UmbracoRedirect");
                }
            }
        }
        private Int32 _UmbracoNaviHide;
        /// <summary>
        /// Use this property if you wish to hide this page in the navigation.
        /// </summary>
        [UmbracoInfo("umbracoNaviHide", DisplayName = "Hide in Navi", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoNaviHide
        {
            get
            {
                return this._UmbracoNaviHide;
            }
            set
            {
                if ((this._UmbracoNaviHide != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoNaviHide = value;
                    this.RaisePropertyChanged("UmbracoNaviHide");
                }
            }
        }
        private String _SiteName;
        /// <summary>
        /// This is what your site is called.
        /// </summary>
        [UmbracoInfo("siteName", DisplayName = "Site Name", Mandatory = false)]
        [Property()]
        public virtual String SiteName
        {
            get
            {
                return this._SiteName;
            }
            set
            {
                if ((this._SiteName != value))
                {
                    this.RaisePropertyChanging();
                    this._SiteName = value;
                    this.RaisePropertyChanged("SiteName");
                }
            }
        }
        private String _HeaderText;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("headerText", DisplayName = "Header", Mandatory = false)]
        [Property()]
        public virtual String HeaderText
        {
            get
            {
                return this._HeaderText;
            }
            set
            {
                if ((this._HeaderText != value))
                {
                    this.RaisePropertyChanging();
                    this._HeaderText = value;
                    this.RaisePropertyChanged("HeaderText");
                }
            }
        }
        private String _HomepagePhoto;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("homepagePhoto", DisplayName = "Photo", Mandatory = false)]
        [Property()]
        public virtual String HomepagePhoto
        {
            get
            {
                return this._HomepagePhoto;
            }
            set
            {
                if ((this._HomepagePhoto != value))
                {
                    this.RaisePropertyChanging();
                    this._HomepagePhoto = value;
                    this.RaisePropertyChanged("HomepagePhoto");
                }
            }
        }
        private String _BodyText;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("bodyText", DisplayName = "Text", Mandatory = false)]
        [Property()]
        public virtual String BodyText
        {
            get
            {
                return this._BodyText;
            }
            set
            {
                if ((this._BodyText != value))
                {
                    this.RaisePropertyChanging();
                    this._BodyText = value;
                    this.RaisePropertyChanged("BodyText");
                }
            }
        }

        private AssociationTree<CWS_Contact> _CWS_Contacts;
        public AssociationTree<CWS_Contact> CWS_Contacts
        {
            get
            {
                if ((this._CWS_Contacts == null))
                {
                    this._CWS_Contacts = this.ChildrenOfType<CWS_Contact>();
                }
                return this._CWS_Contacts;
            }
            set
            {
                this._CWS_Contacts = value;
            }
        }
        private AssociationTree<CWS_EmailAFriend> _CWS_EmailAFriends;
        public AssociationTree<CWS_EmailAFriend> CWS_EmailAFriends
        {
            get
            {
                if ((this._CWS_EmailAFriends == null))
                {
                    this._CWS_EmailAFriends = this.ChildrenOfType<CWS_EmailAFriend>();
                }
                return this._CWS_EmailAFriends;
            }
            set
            {
                this._CWS_EmailAFriends = value;
            }
        }
        private AssociationTree<CWS_Galleries> _CWS_Galleriess;
        public AssociationTree<CWS_Galleries> CWS_Galleriess
        {
            get
            {
                if ((this._CWS_Galleriess == null))
                {
                    this._CWS_Galleriess = this.ChildrenOfType<CWS_Galleries>();
                }
                return this._CWS_Galleriess;
            }
            set
            {
                this._CWS_Galleriess = value;
            }
        }
        private AssociationTree<CWS_NewsEventsList> _CWS_NewsEventsLists;
        public AssociationTree<CWS_NewsEventsList> CWS_NewsEventsLists
        {
            get
            {
                if ((this._CWS_NewsEventsLists == null))
                {
                    this._CWS_NewsEventsLists = this.ChildrenOfType<CWS_NewsEventsList>();
                }
                return this._CWS_NewsEventsLists;
            }
            set
            {
                this._CWS_NewsEventsLists = value;
            }
        }
        private AssociationTree<CWS_Textpage> _CWS_Textpages;
        public AssociationTree<CWS_Textpage> CWS_Textpages
        {
            get
            {
                if ((this._CWS_Textpages == null))
                {
                    this._CWS_Textpages = this.ChildrenOfType<CWS_Textpage>();
                }
                return this._CWS_Textpages;
            }
            set
            {
                this._CWS_Textpages = value;
            }
        }
        private AssociationTree<CWS_TextpageTwoCol> _CWS_TextpageTwoCols;
        public AssociationTree<CWS_TextpageTwoCol> CWS_TextpageTwoCols
        {
            get
            {
                if ((this._CWS_TextpageTwoCols == null))
                {
                    this._CWS_TextpageTwoCols = this.ChildrenOfType<CWS_TextpageTwoCol>();
                }
                return this._CWS_TextpageTwoCols;
            }
            set
            {
                this._CWS_TextpageTwoCols = value;
            }
        }

        IEnumerable<ICWS_Contact> ICWS_Home.CWS_Contacts
        {
            get
            {
                return this.CWS_Contacts.OfType<ICWS_Contact>();
            }
        }
        IEnumerable<ICWS_EmailAFriend> ICWS_Home.CWS_EmailAFriends
        {
            get
            {
                return this.CWS_EmailAFriends.OfType<ICWS_EmailAFriend>();
            }
        }
        IEnumerable<ICWS_Galleries> ICWS_Home.CWS_Galleriess
        {
            get
            {
                return this.CWS_Galleriess.OfType<ICWS_Galleries>();
            }
        }
        IEnumerable<ICWS_NewsEventsList> ICWS_Home.CWS_NewsEventsLists
        {
            get
            {
                return this.CWS_NewsEventsLists.OfType<ICWS_NewsEventsList>();
            }
        }
        IEnumerable<ICWS_Textpage> ICWS_Home.CWS_Textpages
        {
            get
            {
                return this.CWS_Textpages.OfType<ICWS_Textpage>();
            }
        }
        IEnumerable<ICWS_TextpageTwoCol> ICWS_Home.CWS_TextpageTwoCols
        {
            get
            {
                return this.CWS_TextpageTwoCols.OfType<ICWS_TextpageTwoCol>();
            }
        }
    }
    /// <summary>
    /// This is the News & Events List document type for your site which stores the News and Event Item document types as children.
    /// </summary>
    [UmbracoInfo("CWS_NewsEventsList")]
    [System.Runtime.Serialization.DataContractAttribute()]
    [DocType()]
    public partial class CWS_NewsEventsList : DocTypeBase, ICWS_NewsEventsList
    {
        public CWS_NewsEventsList()
        {
        }

        private String _UmbracoUrlName;
        /// <summary>
        /// If you wish to change the URL of the node without changing the node name fill this in.
        ///
        ///eg: warren
        /// </summary>
        [UmbracoInfo("umbracoUrlName", DisplayName = "Umbraco URL Name", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlName
        {
            get
            {
                return this._UmbracoUrlName;
            }
            set
            {
                if ((this._UmbracoUrlName != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlName = value;
                    this.RaisePropertyChanged("UmbracoUrlName");
                }
            }
        }
        private String _UmbracoUrlAlias;
        /// <summary>
        /// Use this to give a node multiple urls.
        ///
        ///eg: home,homepage/another-level
        /// </summary>
        [UmbracoInfo("umbracoUrlAlias", DisplayName = "Umbraco URL Alias", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlAlias
        {
            get
            {
                return this._UmbracoUrlAlias;
            }
            set
            {
                if ((this._UmbracoUrlAlias != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlAlias = value;
                    this.RaisePropertyChanged("UmbracoUrlAlias");
                }
            }
        }
        private String _MetaDescription;
        /// <summary>
        /// Enter the description for the page.
        /// </summary>
        [UmbracoInfo("metaDescription", DisplayName = "Meta Description", Mandatory = false)]
        [Property()]
        public virtual String MetaDescription
        {
            get
            {
                return this._MetaDescription;
            }
            set
            {
                if ((this._MetaDescription != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaDescription = value;
                    this.RaisePropertyChanged("MetaDescription");
                }
            }
        }
        private String _MetaKeywords;
        /// <summary>
        /// Enter a comma seperated list of keywords.
        ///warren, keyword, test
        /// </summary>
        [UmbracoInfo("metaKeywords", DisplayName = "Meta Keywords", Mandatory = false)]
        [Property()]
        public virtual String MetaKeywords
        {
            get
            {
                return this._MetaKeywords;
            }
            set
            {
                if ((this._MetaKeywords != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaKeywords = value;
                    this.RaisePropertyChanged("MetaKeywords");
                }
            }
        }
        private Int32 _UmbracoRedirect;
        /// <summary>
        /// Pick a node you wish to redirect to if the user lands on this node.
        /// </summary>
        [UmbracoInfo("umbracoRedirect", DisplayName = " Umbraco Redirect", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoRedirect
        {
            get
            {
                return this._UmbracoRedirect;
            }
            set
            {
                if ((this._UmbracoRedirect != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoRedirect = value;
                    this.RaisePropertyChanged("UmbracoRedirect");
                }
            }
        }
        private Int32 _UmbracoNaviHide;
        /// <summary>
        /// Use this property if you wish to hide this page in the navigation.
        /// </summary>
        [UmbracoInfo("umbracoNaviHide", DisplayName = "Hide in Navi", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoNaviHide
        {
            get
            {
                return this._UmbracoNaviHide;
            }
            set
            {
                if ((this._UmbracoNaviHide != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoNaviHide = value;
                    this.RaisePropertyChanged("UmbracoNaviHide");
                }
            }
        }
        private String _SortBy;
        /// <summary>
        /// Choose how you want to sort the child items.
        /// </summary>
        [UmbracoInfo("sortBy", DisplayName = "Sort By", Mandatory = true)]
        [Property()]
        public virtual String SortBy
        {
            get
            {
                return this._SortBy;
            }
            set
            {
                if ((this._SortBy != value))
                {
                    this.RaisePropertyChanging();
                    this._SortBy = value;
                    this.RaisePropertyChanged("SortBy");
                }
            }
        }
        private String _SortOrder;
        /// <summary>
        /// Choose how you want to sort the child items.
        /// </summary>
        [UmbracoInfo("sortOrder", DisplayName = "Sort Order", Mandatory = true)]
        [Property()]
        public virtual String SortOrder
        {
            get
            {
                return this._SortOrder;
            }
            set
            {
                if ((this._SortOrder != value))
                {
                    this.RaisePropertyChanging();
                    this._SortOrder = value;
                    this.RaisePropertyChanged("SortOrder");
                }
            }
        }
        private String _HeaderText;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("headerText", DisplayName = "Header", Mandatory = false)]
        [Property()]
        public virtual String HeaderText
        {
            get
            {
                return this._HeaderText;
            }
            set
            {
                if ((this._HeaderText != value))
                {
                    this.RaisePropertyChanging();
                    this._HeaderText = value;
                    this.RaisePropertyChanged("HeaderText");
                }
            }
        }

        private AssociationTree<CWS_EventItem> _CWS_EventItems;
        public AssociationTree<CWS_EventItem> CWS_EventItems
        {
            get
            {
                if ((this._CWS_EventItems == null))
                {
                    this._CWS_EventItems = this.ChildrenOfType<CWS_EventItem>();
                }
                return this._CWS_EventItems;
            }
            set
            {
                this._CWS_EventItems = value;
            }
        }
        private AssociationTree<CWS_NewsItem> _CWS_NewsItems;
        public AssociationTree<CWS_NewsItem> CWS_NewsItems
        {
            get
            {
                if ((this._CWS_NewsItems == null))
                {
                    this._CWS_NewsItems = this.ChildrenOfType<CWS_NewsItem>();
                }
                return this._CWS_NewsItems;
            }
            set
            {
                this._CWS_NewsItems = value;
            }
        }

        IEnumerable<ICWS_EventItem> ICWS_NewsEventsList.CWS_EventItems
        {
            get
            {
                return this.CWS_EventItems.OfType<ICWS_EventItem>();
            }
        }
        IEnumerable<ICWS_NewsItem> ICWS_NewsEventsList.CWS_NewsItems
        {
            get
            {
                return this.CWS_NewsItems.OfType<ICWS_NewsItem>();
            }
        }
    }
    /// <summary>
    /// This is the news document type for your site and lives beneath the News & Events List document type.
    /// </summary>
    [UmbracoInfo("CWS_NewsItem")]
    [System.Runtime.Serialization.DataContractAttribute()]
    [DocType()]
    public partial class CWS_NewsItem : DocTypeBase, ICWS_NewsItem
    {
        public CWS_NewsItem()
        {
        }

        private String _BodyText;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("bodyText", DisplayName = "Text", Mandatory = false)]
        [Property()]
        public virtual String BodyText
        {
            get
            {
                return this._BodyText;
            }
            set
            {
                if ((this._BodyText != value))
                {
                    this.RaisePropertyChanging();
                    this._BodyText = value;
                    this.RaisePropertyChanged("BodyText");
                }
            }
        }
        private String _ArticlePhoto;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("articlePhoto", DisplayName = "Photo", Mandatory = false)]
        [Property()]
        public virtual String ArticlePhoto
        {
            get
            {
                return this._ArticlePhoto;
            }
            set
            {
                if ((this._ArticlePhoto != value))
                {
                    this.RaisePropertyChanging();
                    this._ArticlePhoto = value;
                    this.RaisePropertyChanged("ArticlePhoto");
                }
            }
        }
        private String _UmbracoUrlName;
        /// <summary>
        /// If you wish to change the URL of the node without changing the node name fill this in.
        ///
        ///eg: warren
        /// </summary>
        [UmbracoInfo("umbracoUrlName", DisplayName = "Umbraco URL Name", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlName
        {
            get
            {
                return this._UmbracoUrlName;
            }
            set
            {
                if ((this._UmbracoUrlName != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlName = value;
                    this.RaisePropertyChanged("UmbracoUrlName");
                }
            }
        }
        private String _UmbracoUrlAlias;
        /// <summary>
        /// Use this to give a node multiple urls.
        ///
        ///eg: home,homepage/another-level
        /// </summary>
        [UmbracoInfo("umbracoUrlAlias", DisplayName = "Umbraco URL Alias", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlAlias
        {
            get
            {
                return this._UmbracoUrlAlias;
            }
            set
            {
                if ((this._UmbracoUrlAlias != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlAlias = value;
                    this.RaisePropertyChanged("UmbracoUrlAlias");
                }
            }
        }
        private String _MetaDescription;
        /// <summary>
        /// Enter the description for the page.
        /// </summary>
        [UmbracoInfo("metaDescription", DisplayName = "Meta Description", Mandatory = false)]
        [Property()]
        public virtual String MetaDescription
        {
            get
            {
                return this._MetaDescription;
            }
            set
            {
                if ((this._MetaDescription != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaDescription = value;
                    this.RaisePropertyChanged("MetaDescription");
                }
            }
        }
        private String _MetaKeywords;
        /// <summary>
        /// Enter a comma seperated list of keywords.
        ///warren, keyword, test
        /// </summary>
        [UmbracoInfo("metaKeywords", DisplayName = "Meta Keywords", Mandatory = false)]
        [Property()]
        public virtual String MetaKeywords
        {
            get
            {
                return this._MetaKeywords;
            }
            set
            {
                if ((this._MetaKeywords != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaKeywords = value;
                    this.RaisePropertyChanged("MetaKeywords");
                }
            }
        }
        private Int32 _UmbracoRedirect;
        /// <summary>
        /// Pick a node you wish to redirect to if the user lands on this node.
        /// </summary>
        [UmbracoInfo("umbracoRedirect", DisplayName = " Umbraco Redirect", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoRedirect
        {
            get
            {
                return this._UmbracoRedirect;
            }
            set
            {
                if ((this._UmbracoRedirect != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoRedirect = value;
                    this.RaisePropertyChanged("UmbracoRedirect");
                }
            }
        }
        private Int32 _UmbracoNaviHide;
        /// <summary>
        /// Use this property if you wish to hide this page in the navigation.
        /// </summary>
        [UmbracoInfo("umbracoNaviHide", DisplayName = "Hide in Navi", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoNaviHide
        {
            get
            {
                return this._UmbracoNaviHide;
            }
            set
            {
                if ((this._UmbracoNaviHide != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoNaviHide = value;
                    this.RaisePropertyChanged("UmbracoNaviHide");
                }
            }
        }

        private AssociationTree<CWS_NewsItem> _CWS_NewsItems;
        public AssociationTree<CWS_NewsItem> CWS_NewsItems
        {
            get
            {
                if ((this._CWS_NewsItems == null))
                {
                    this._CWS_NewsItems = this.ChildrenOfType<CWS_NewsItem>();
                }
                return this._CWS_NewsItems;
            }
            set
            {
                this._CWS_NewsItems = value;
            }
        }

        IEnumerable<ICWS_NewsItem> ICWS_NewsItem.CWS_NewsItems
        {
            get
            {
                return this.CWS_NewsItems.OfType<ICWS_NewsItem>();
            }
        }
    }
    /// <summary>
    /// This is the Photo document type for your site and lives beneath the Gallery document type.
    /// </summary>
    [UmbracoInfo("CWS_Photo")]
    [System.Runtime.Serialization.DataContractAttribute()]
    [DocType()]
    public partial class CWS_Photo : DocTypeBase, ICWS_Photo
    {
        public CWS_Photo()
        {
        }

        private String _PhotoText;
        /// <summary>
        /// Enter a description
        /// </summary>
        [UmbracoInfo("photoText", DisplayName = "Photo Text", Mandatory = false)]
        [Property()]
        public virtual String PhotoText
        {
            get
            {
                return this._PhotoText;
            }
            set
            {
                if ((this._PhotoText != value))
                {
                    this.RaisePropertyChanging();
                    this._PhotoText = value;
                    this.RaisePropertyChanged("PhotoText");
                }
            }
        }
        private String _Photo;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("photo", DisplayName = "Photo", Mandatory = false)]
        [Property()]
        public virtual String Photo
        {
            get
            {
                return this._Photo;
            }
            set
            {
                if ((this._Photo != value))
                {
                    this.RaisePropertyChanging();
                    this._Photo = value;
                    this.RaisePropertyChanged("Photo");
                }
            }
        }
        private String _PhotoThumbnail;
        /// <summary>
        /// 151px x 108px
        /// </summary>
        [UmbracoInfo("photoThumbnail", DisplayName = "Thumbnail", Mandatory = false)]
        [Property()]
        public virtual String PhotoThumbnail
        {
            get
            {
                return this._PhotoThumbnail;
            }
            set
            {
                if ((this._PhotoThumbnail != value))
                {
                    this.RaisePropertyChanging();
                    this._PhotoThumbnail = value;
                    this.RaisePropertyChanged("PhotoThumbnail");
                }
            }
        }
        private String _UmbracoUrlName;
        /// <summary>
        /// If you wish to change the URL of the node without changing the node name fill this in.
        ///
        ///eg: warren
        /// </summary>
        [UmbracoInfo("umbracoUrlName", DisplayName = "Umbraco URL Name", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlName
        {
            get
            {
                return this._UmbracoUrlName;
            }
            set
            {
                if ((this._UmbracoUrlName != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlName = value;
                    this.RaisePropertyChanged("UmbracoUrlName");
                }
            }
        }
        private String _UmbracoUrlAlias;
        /// <summary>
        /// Use this to give a node multiple urls.
        ///
        ///eg: home,homepage/another-level
        /// </summary>
        [UmbracoInfo("umbracoUrlAlias", DisplayName = "Umbraco URL Alias", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlAlias
        {
            get
            {
                return this._UmbracoUrlAlias;
            }
            set
            {
                if ((this._UmbracoUrlAlias != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlAlias = value;
                    this.RaisePropertyChanged("UmbracoUrlAlias");
                }
            }
        }
        private String _MetaDescription;
        /// <summary>
        /// Enter the description for the page.
        /// </summary>
        [UmbracoInfo("metaDescription", DisplayName = "Meta Description", Mandatory = false)]
        [Property()]
        public virtual String MetaDescription
        {
            get
            {
                return this._MetaDescription;
            }
            set
            {
                if ((this._MetaDescription != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaDescription = value;
                    this.RaisePropertyChanged("MetaDescription");
                }
            }
        }
        private String _MetaKeywords;
        /// <summary>
        /// Enter a comma seperated list of keywords.
        ///warren, keyword, test
        /// </summary>
        [UmbracoInfo("metaKeywords", DisplayName = "Meta Keywords", Mandatory = false)]
        [Property()]
        public virtual String MetaKeywords
        {
            get
            {
                return this._MetaKeywords;
            }
            set
            {
                if ((this._MetaKeywords != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaKeywords = value;
                    this.RaisePropertyChanged("MetaKeywords");
                }
            }
        }
        private Int32 _UmbracoRedirect;
        /// <summary>
        /// Pick a node you wish to redirect to if the user lands on this node.
        /// </summary>
        [UmbracoInfo("umbracoRedirect", DisplayName = " Umbraco Redirect", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoRedirect
        {
            get
            {
                return this._UmbracoRedirect;
            }
            set
            {
                if ((this._UmbracoRedirect != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoRedirect = value;
                    this.RaisePropertyChanged("UmbracoRedirect");
                }
            }
        }
        private Int32 _UmbracoNaviHide;
        /// <summary>
        /// Use this property if you wish to hide this page in the navigation.
        /// </summary>
        [UmbracoInfo("umbracoNaviHide", DisplayName = "Hide in Navi", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoNaviHide
        {
            get
            {
                return this._UmbracoNaviHide;
            }
            set
            {
                if ((this._UmbracoNaviHide != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoNaviHide = value;
                    this.RaisePropertyChanged("UmbracoNaviHide");
                }
            }
        }


    }
    /// <summary>
    /// This is the Textpage document type for your site.
    /// </summary>
    [UmbracoInfo("CWS_Textpage")]
    [System.Runtime.Serialization.DataContractAttribute()]
    [DocType()]
    public partial class CWS_Textpage : DocTypeBase, ICWS_Textpage
    {
        public CWS_Textpage()
        {
        }

        private String _UmbracoUrlName;
        /// <summary>
        /// If you wish to change the URL of the node without changing the node name fill this in.
        ///
        ///eg: warren
        /// </summary>
        [UmbracoInfo("umbracoUrlName", DisplayName = "Umbraco URL Name", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlName
        {
            get
            {
                return this._UmbracoUrlName;
            }
            set
            {
                if ((this._UmbracoUrlName != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlName = value;
                    this.RaisePropertyChanged("UmbracoUrlName");
                }
            }
        }
        private String _UmbracoUrlAlias;
        /// <summary>
        /// Use this to give a node multiple urls.
        ///
        ///eg: home,homepage/another-level
        /// </summary>
        [UmbracoInfo("umbracoUrlAlias", DisplayName = "Umbraco URL Alias", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlAlias
        {
            get
            {
                return this._UmbracoUrlAlias;
            }
            set
            {
                if ((this._UmbracoUrlAlias != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlAlias = value;
                    this.RaisePropertyChanged("UmbracoUrlAlias");
                }
            }
        }
        private String _MetaDescription;
        /// <summary>
        /// Enter the description for the page.
        /// </summary>
        [UmbracoInfo("metaDescription", DisplayName = "Meta Description", Mandatory = false)]
        [Property()]
        public virtual String MetaDescription
        {
            get
            {
                return this._MetaDescription;
            }
            set
            {
                if ((this._MetaDescription != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaDescription = value;
                    this.RaisePropertyChanged("MetaDescription");
                }
            }
        }
        private String _MetaKeywords;
        /// <summary>
        /// Enter a comma seperated list of keywords.
        ///warren, keyword, test
        /// </summary>
        [UmbracoInfo("metaKeywords", DisplayName = "Meta Keywords", Mandatory = false)]
        [Property()]
        public virtual String MetaKeywords
        {
            get
            {
                return this._MetaKeywords;
            }
            set
            {
                if ((this._MetaKeywords != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaKeywords = value;
                    this.RaisePropertyChanged("MetaKeywords");
                }
            }
        }
        private Int32 _UmbracoRedirect;
        /// <summary>
        /// Pick a node you wish to redirect to if the user lands on this node.
        /// </summary>
        [UmbracoInfo("umbracoRedirect", DisplayName = " Umbraco Redirect", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoRedirect
        {
            get
            {
                return this._UmbracoRedirect;
            }
            set
            {
                if ((this._UmbracoRedirect != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoRedirect = value;
                    this.RaisePropertyChanged("UmbracoRedirect");
                }
            }
        }
        private Int32 _UmbracoNaviHide;
        /// <summary>
        /// Use this property if you wish to hide this page in the navigation.
        /// </summary>
        [UmbracoInfo("umbracoNaviHide", DisplayName = "Hide in Navi", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoNaviHide
        {
            get
            {
                return this._UmbracoNaviHide;
            }
            set
            {
                if ((this._UmbracoNaviHide != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoNaviHide = value;
                    this.RaisePropertyChanged("UmbracoNaviHide");
                }
            }
        }
        private String _HeaderText;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("headerText", DisplayName = "Header", Mandatory = false)]
        [Property()]
        public virtual String HeaderText
        {
            get
            {
                return this._HeaderText;
            }
            set
            {
                if ((this._HeaderText != value))
                {
                    this.RaisePropertyChanging();
                    this._HeaderText = value;
                    this.RaisePropertyChanged("HeaderText");
                }
            }
        }
        private String _ArticlePhoto;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("articlePhoto", DisplayName = "Photo", Mandatory = false)]
        [Property()]
        public virtual String ArticlePhoto
        {
            get
            {
                return this._ArticlePhoto;
            }
            set
            {
                if ((this._ArticlePhoto != value))
                {
                    this.RaisePropertyChanging();
                    this._ArticlePhoto = value;
                    this.RaisePropertyChanged("ArticlePhoto");
                }
            }
        }
        private String _BodyText;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("bodyText", DisplayName = "Text", Mandatory = false)]
        [Property()]
        public virtual String BodyText
        {
            get
            {
                return this._BodyText;
            }
            set
            {
                if ((this._BodyText != value))
                {
                    this.RaisePropertyChanging();
                    this._BodyText = value;
                    this.RaisePropertyChanged("BodyText");
                }
            }
        }

        private AssociationTree<CWS_Textpage> _CWS_Textpages;
        public AssociationTree<CWS_Textpage> CWS_Textpages
        {
            get
            {
                if ((this._CWS_Textpages == null))
                {
                    this._CWS_Textpages = this.ChildrenOfType<CWS_Textpage>();
                }
                return this._CWS_Textpages;
            }
            set
            {
                this._CWS_Textpages = value;
            }
        }
        private AssociationTree<CWS_TextpageTwoCol> _CWS_TextpageTwoCols;
        public AssociationTree<CWS_TextpageTwoCol> CWS_TextpageTwoCols
        {
            get
            {
                if ((this._CWS_TextpageTwoCols == null))
                {
                    this._CWS_TextpageTwoCols = this.ChildrenOfType<CWS_TextpageTwoCol>();
                }
                return this._CWS_TextpageTwoCols;
            }
            set
            {
                this._CWS_TextpageTwoCols = value;
            }
        }

        IEnumerable<ICWS_Textpage> ICWS_Textpage.CWS_Textpages
        {
            get
            {
                return this.CWS_Textpages.OfType<ICWS_Textpage>();
            }
        }
        IEnumerable<ICWS_TextpageTwoCol> ICWS_Textpage.CWS_TextpageTwoCols
        {
            get
            {
                return this.CWS_TextpageTwoCols.OfType<ICWS_TextpageTwoCol>();
            }
        }
    }
    /// <summary>
    /// This is the Textpage document type for your site which has two columns.
    /// </summary>
    [UmbracoInfo("CWS_TextpageTwoCol")]
    [System.Runtime.Serialization.DataContractAttribute()]
    [DocType()]
    public partial class CWS_TextpageTwoCol : DocTypeBase, ICWS_TextpageTwoCol
    {
        public CWS_TextpageTwoCol()
        {
        }

        private String _ArticlePhotoColOne;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("articlePhotoColOne", DisplayName = "Photo", Mandatory = false)]
        [Property()]
        public virtual String ArticlePhotoColOne
        {
            get
            {
                return this._ArticlePhotoColOne;
            }
            set
            {
                if ((this._ArticlePhotoColOne != value))
                {
                    this.RaisePropertyChanging();
                    this._ArticlePhotoColOne = value;
                    this.RaisePropertyChanged("ArticlePhotoColOne");
                }
            }
        }
        private String _ArticlePhotoColTwo;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("articlePhotoColTwo", DisplayName = "Photo", Mandatory = false)]
        [Property()]
        public virtual String ArticlePhotoColTwo
        {
            get
            {
                return this._ArticlePhotoColTwo;
            }
            set
            {
                if ((this._ArticlePhotoColTwo != value))
                {
                    this.RaisePropertyChanging();
                    this._ArticlePhotoColTwo = value;
                    this.RaisePropertyChanged("ArticlePhotoColTwo");
                }
            }
        }
        private String _BodyTextColTwo;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("bodyTextColTwo", DisplayName = "Text", Mandatory = false)]
        [Property()]
        public virtual String BodyTextColTwo
        {
            get
            {
                return this._BodyTextColTwo;
            }
            set
            {
                if ((this._BodyTextColTwo != value))
                {
                    this.RaisePropertyChanging();
                    this._BodyTextColTwo = value;
                    this.RaisePropertyChanged("BodyTextColTwo");
                }
            }
        }
        private String _BodyTextColOne;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("bodyTextColOne", DisplayName = "Text", Mandatory = false)]
        [Property()]
        public virtual String BodyTextColOne
        {
            get
            {
                return this._BodyTextColOne;
            }
            set
            {
                if ((this._BodyTextColOne != value))
                {
                    this.RaisePropertyChanging();
                    this._BodyTextColOne = value;
                    this.RaisePropertyChanged("BodyTextColOne");
                }
            }
        }
        private String _UmbracoUrlName;
        /// <summary>
        /// If you wish to change the URL of the node without changing the node name fill this in.
        ///
        ///eg: warren
        /// </summary>
        [UmbracoInfo("umbracoUrlName", DisplayName = "Umbraco URL Name", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlName
        {
            get
            {
                return this._UmbracoUrlName;
            }
            set
            {
                if ((this._UmbracoUrlName != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlName = value;
                    this.RaisePropertyChanged("UmbracoUrlName");
                }
            }
        }
        private String _UmbracoUrlAlias;
        /// <summary>
        /// Use this to give a node multiple urls.
        ///
        ///eg: home,homepage/another-level
        /// </summary>
        [UmbracoInfo("umbracoUrlAlias", DisplayName = "Umbraco URL Alias", Mandatory = false)]
        [Property()]
        public virtual String UmbracoUrlAlias
        {
            get
            {
                return this._UmbracoUrlAlias;
            }
            set
            {
                if ((this._UmbracoUrlAlias != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoUrlAlias = value;
                    this.RaisePropertyChanged("UmbracoUrlAlias");
                }
            }
        }
        private String _MetaDescription;
        /// <summary>
        /// Enter the description for the page.
        /// </summary>
        [UmbracoInfo("metaDescription", DisplayName = "Meta Description", Mandatory = false)]
        [Property()]
        public virtual String MetaDescription
        {
            get
            {
                return this._MetaDescription;
            }
            set
            {
                if ((this._MetaDescription != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaDescription = value;
                    this.RaisePropertyChanged("MetaDescription");
                }
            }
        }
        private String _MetaKeywords;
        /// <summary>
        /// Enter a comma seperated list of keywords.
        ///warren, keyword, test
        /// </summary>
        [UmbracoInfo("metaKeywords", DisplayName = "Meta Keywords", Mandatory = false)]
        [Property()]
        public virtual String MetaKeywords
        {
            get
            {
                return this._MetaKeywords;
            }
            set
            {
                if ((this._MetaKeywords != value))
                {
                    this.RaisePropertyChanging();
                    this._MetaKeywords = value;
                    this.RaisePropertyChanged("MetaKeywords");
                }
            }
        }
        private Int32 _UmbracoRedirect;
        /// <summary>
        /// Pick a node you wish to redirect to if the user lands on this node.
        /// </summary>
        [UmbracoInfo("umbracoRedirect", DisplayName = " Umbraco Redirect", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoRedirect
        {
            get
            {
                return this._UmbracoRedirect;
            }
            set
            {
                if ((this._UmbracoRedirect != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoRedirect = value;
                    this.RaisePropertyChanged("UmbracoRedirect");
                }
            }
        }
        private Int32 _UmbracoNaviHide;
        /// <summary>
        /// Use this property if you wish to hide this page in the navigation.
        /// </summary>
        [UmbracoInfo("umbracoNaviHide", DisplayName = "Hide in Navi", Mandatory = false)]
        [Property()]
        public virtual Int32 UmbracoNaviHide
        {
            get
            {
                return this._UmbracoNaviHide;
            }
            set
            {
                if ((this._UmbracoNaviHide != value))
                {
                    this.RaisePropertyChanging();
                    this._UmbracoNaviHide = value;
                    this.RaisePropertyChanged("UmbracoNaviHide");
                }
            }
        }
        private String _HeaderText;
        /// <summary>
        /// 
        /// </summary>
        [UmbracoInfo("headerText", DisplayName = "Header", Mandatory = false)]
        [Property()]
        public virtual String HeaderText
        {
            get
            {
                return this._HeaderText;
            }
            set
            {
                if ((this._HeaderText != value))
                {
                    this.RaisePropertyChanging();
                    this._HeaderText = value;
                    this.RaisePropertyChanged("HeaderText");
                }
            }
        }

        private AssociationTree<CWS_Textpage> _CWS_Textpages;
        public AssociationTree<CWS_Textpage> CWS_Textpages
        {
            get
            {
                if ((this._CWS_Textpages == null))
                {
                    this._CWS_Textpages = this.ChildrenOfType<CWS_Textpage>();
                }
                return this._CWS_Textpages;
            }
            set
            {
                this._CWS_Textpages = value;
            }
        }
        private AssociationTree<CWS_TextpageTwoCol> _CWS_TextpageTwoCols;
        public AssociationTree<CWS_TextpageTwoCol> CWS_TextpageTwoCols
        {
            get
            {
                if ((this._CWS_TextpageTwoCols == null))
                {
                    this._CWS_TextpageTwoCols = this.ChildrenOfType<CWS_TextpageTwoCol>();
                }
                return this._CWS_TextpageTwoCols;
            }
            set
            {
                this._CWS_TextpageTwoCols = value;
            }
        }

        IEnumerable<ICWS_Textpage> ICWS_TextpageTwoCol.CWS_Textpages
        {
            get
            {
                return this.CWS_Textpages.OfType<ICWS_Textpage>();
            }
        }
        IEnumerable<ICWS_TextpageTwoCol> ICWS_TextpageTwoCol.CWS_TextpageTwoCols
        {
            get
            {
                return this.CWS_TextpageTwoCols.OfType<ICWS_TextpageTwoCol>();
            }
        }
    }
}