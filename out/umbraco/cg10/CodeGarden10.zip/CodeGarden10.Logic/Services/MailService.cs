﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;

namespace CodeGarden10.Logic.Services
{
    internal class MailService : IMailService
    {
        private SmtpClient smtp;

        public MailService()
        {
            this.smtp = new SmtpClient();
        }

        #region IMailService Members

        public void Send(System.Net.Mail.MailMessage message)
        {
            this.Send(message, false);
        }

        public void Send(System.Net.Mail.MailMessage mm, bool enableSsl)
        {
            smtp.EnableSsl = enableSsl;
            smtp.Send(mm);
        }

        #endregion
    }
}
