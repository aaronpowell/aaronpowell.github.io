using System;
using System.Linq;
using umbraco.Linq.Core;
using System.Collections.Generic;

namespace CodeGarden10.Logic.Services {
	public interface ICodeGarden10DataContext : IUmbracoDataContext {
        IEnumerable<ICWS_Contact> CWS_Contacts { get; }
IEnumerable<ICWS_EmailAFriend> CWS_EmailAFriends { get; }
IEnumerable<ICWS_EventItem> CWS_EventItems { get; }
IEnumerable<ICWS_Galleries> CWS_Galleriess { get; }
IEnumerable<ICWS_Gallery> CWS_Gallerys { get; }
IEnumerable<ICWS_Home> CWS_Homes { get; }
IEnumerable<ICWS_NewsEventsList> CWS_NewsEventsLists { get; }
IEnumerable<ICWS_NewsItem> CWS_NewsItems { get; }
IEnumerable<ICWS_Photo> CWS_Photos { get; }
IEnumerable<ICWS_Textpage> CWS_Textpages { get; }
IEnumerable<ICWS_TextpageTwoCol> CWS_TextpageTwoCols { get; }

	}

    
    public interface ICWS_Contact : IDocTypeBase {
        String EmailTo { get; set; }
String EmailSubject { get; set; }
String EmailBody { get; set; }
String EmailReplyFrom { get; set; }
String EmailReplySubject { get; set; }
String EmailReplyBody { get; set; }
Int32 EnableSSL { get; set; }
String UmbracoUrlName { get; set; }
String UmbracoUrlAlias { get; set; }
String MetaDescription { get; set; }
String MetaKeywords { get; set; }
Int32 UmbracoRedirect { get; set; }
Int32 UmbracoNaviHide { get; set; }
String HeaderText { get; set; }
String FormText { get; set; }
String ThankYouHeaderText { get; set; }
String ThankYouMessageText { get; set; }

        IEnumerable<ICWS_Textpage> CWS_Textpages { get; }

}

    public interface ICWS_EmailAFriend : IDocTypeBase {
        String EmailFrom { get; set; }
String EmailSubjectToFriend { get; set; }
String EmailMessageToFriend { get; set; }
Int32 EnableSSL { get; set; }
String UmbracoUrlName { get; set; }
String UmbracoUrlAlias { get; set; }
String MetaDescription { get; set; }
String MetaKeywords { get; set; }
Int32 UmbracoRedirect { get; set; }
Int32 UmbracoNaviHide { get; set; }
String HeaderText { get; set; }
String ThankYouHeaderText { get; set; }
String ThankYouMessageText { get; set; }

        IEnumerable<ICWS_Textpage> CWS_Textpages { get; }

}

    public interface ICWS_EventItem : IDocTypeBase {
        DateTime EventDate { get; set; }
String BodyText { get; set; }
String ArticlePhoto { get; set; }
String UmbracoUrlName { get; set; }
String UmbracoUrlAlias { get; set; }
String MetaDescription { get; set; }
String MetaKeywords { get; set; }
Int32 UmbracoRedirect { get; set; }
Int32 UmbracoNaviHide { get; set; }

        
}

    public interface ICWS_Galleries : IDocTypeBase {
        String UmbracoUrlName { get; set; }
String UmbracoUrlAlias { get; set; }
String MetaDescription { get; set; }
String MetaKeywords { get; set; }
Int32 UmbracoRedirect { get; set; }
Int32 UmbracoNaviHide { get; set; }
String HeaderText { get; set; }
String SortBy { get; set; }
String SortOrder { get; set; }

        IEnumerable<ICWS_Gallery> CWS_Gallerys { get; }

}

    public interface ICWS_Gallery : IDocTypeBase {
        String UmbracoUrlName { get; set; }
String UmbracoUrlAlias { get; set; }
String MetaDescription { get; set; }
String MetaKeywords { get; set; }
Int32 UmbracoRedirect { get; set; }
Int32 UmbracoNaviHide { get; set; }
String HeaderText { get; set; }
String SortBy { get; set; }
String SortOrder { get; set; }
String GalleryThumbnail { get; set; }

        IEnumerable<ICWS_Photo> CWS_Photos { get; }

}

    public interface ICWS_Home : IDocTypeBase {
        String UmbracoUrlName { get; set; }
String UmbracoUrlAlias { get; set; }
String MetaDescription { get; set; }
String MetaKeywords { get; set; }
Int32 UmbracoRedirect { get; set; }
Int32 UmbracoNaviHide { get; set; }
String SiteName { get; set; }
String HeaderText { get; set; }
String HomepagePhoto { get; set; }
String BodyText { get; set; }

        IEnumerable<ICWS_Contact> CWS_Contacts { get; }
IEnumerable<ICWS_EmailAFriend> CWS_EmailAFriends { get; }
IEnumerable<ICWS_Galleries> CWS_Galleriess { get; }
IEnumerable<ICWS_NewsEventsList> CWS_NewsEventsLists { get; }
IEnumerable<ICWS_Textpage> CWS_Textpages { get; }
IEnumerable<ICWS_TextpageTwoCol> CWS_TextpageTwoCols { get; }

}

    public interface ICWS_NewsEventsList : IDocTypeBase {
        String UmbracoUrlName { get; set; }
String UmbracoUrlAlias { get; set; }
String MetaDescription { get; set; }
String MetaKeywords { get; set; }
Int32 UmbracoRedirect { get; set; }
Int32 UmbracoNaviHide { get; set; }
String SortBy { get; set; }
String SortOrder { get; set; }
String HeaderText { get; set; }

        IEnumerable<ICWS_EventItem> CWS_EventItems { get; }
IEnumerable<ICWS_NewsItem> CWS_NewsItems { get; }

}

    public interface ICWS_NewsItem : IDocTypeBase {
        String BodyText { get; set; }
String ArticlePhoto { get; set; }
String UmbracoUrlName { get; set; }
String UmbracoUrlAlias { get; set; }
String MetaDescription { get; set; }
String MetaKeywords { get; set; }
Int32 UmbracoRedirect { get; set; }
Int32 UmbracoNaviHide { get; set; }

        IEnumerable<ICWS_NewsItem> CWS_NewsItems { get; }

}

    public interface ICWS_Photo : IDocTypeBase {
        String PhotoText { get; set; }
String Photo { get; set; }
String PhotoThumbnail { get; set; }
String UmbracoUrlName { get; set; }
String UmbracoUrlAlias { get; set; }
String MetaDescription { get; set; }
String MetaKeywords { get; set; }
Int32 UmbracoRedirect { get; set; }
Int32 UmbracoNaviHide { get; set; }

        
}

    public interface ICWS_Textpage : IDocTypeBase {
        String UmbracoUrlName { get; set; }
String UmbracoUrlAlias { get; set; }
String MetaDescription { get; set; }
String MetaKeywords { get; set; }
Int32 UmbracoRedirect { get; set; }
Int32 UmbracoNaviHide { get; set; }
String HeaderText { get; set; }
String ArticlePhoto { get; set; }
String BodyText { get; set; }

        IEnumerable<ICWS_Textpage> CWS_Textpages { get; }
IEnumerable<ICWS_TextpageTwoCol> CWS_TextpageTwoCols { get; }

}

    public interface ICWS_TextpageTwoCol : IDocTypeBase {
        String ArticlePhotoColOne { get; set; }
String ArticlePhotoColTwo { get; set; }
String BodyTextColTwo { get; set; }
String BodyTextColOne { get; set; }
String UmbracoUrlName { get; set; }
String UmbracoUrlAlias { get; set; }
String MetaDescription { get; set; }
String MetaKeywords { get; set; }
Int32 UmbracoRedirect { get; set; }
Int32 UmbracoNaviHide { get; set; }
String HeaderText { get; set; }

        IEnumerable<ICWS_Textpage> CWS_Textpages { get; }
IEnumerable<ICWS_TextpageTwoCol> CWS_TextpageTwoCols { get; }

}

}