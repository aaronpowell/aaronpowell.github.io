﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;

namespace CodeGarden10.Logic.Services
{
    public interface IMailService
    {
        void Send(MailMessage message);

        void Send(MailMessage mm, bool enableSsl);
    }
}
