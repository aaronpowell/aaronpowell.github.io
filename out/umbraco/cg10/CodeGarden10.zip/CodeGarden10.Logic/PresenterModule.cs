﻿using Autofac;
using WebFormsMvp.Contrib.Autofac;

namespace CodeGarden10.Logic
{
    public class PresenterModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            base.Load(builder);

            builder
                .RegisterPresenters(System.Reflection.Assembly.GetExecutingAssembly());
        }
    }
}
