﻿using Autofac;
using CodeGarden10.Logic;
using WebFormsMvp.Binder;
using WebFormsMvp.Contrib.Autofac;

namespace CodeGarden10.Web
{
    public class Global : TheFarm.Snapshot.Web.Cms.Global
    {
        protected override void RegisterTypes(Autofac.ContainerBuilder builder)
        {
            base.RegisterTypes(builder);

            builder.RegisterModule<ServiceModule>();
            builder.RegisterModule<PresenterModule>();
        }

        protected override void RegisterContainer(IContainer container)
        {
            base.RegisterContainer(container);

            PresenterBinder.Factory = new AutofacPresenterFactory(this.ContainerProvider);
        }
    }
}