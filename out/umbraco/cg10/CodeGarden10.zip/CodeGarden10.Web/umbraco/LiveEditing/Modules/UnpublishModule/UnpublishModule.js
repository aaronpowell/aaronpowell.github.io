﻿/********************* Live Editing UnpublishModule functions *********************/
function UnpublishModuleOk()
{
    UmbracoCommunicator.SendClientMessage('unpublishcontent', '');
}