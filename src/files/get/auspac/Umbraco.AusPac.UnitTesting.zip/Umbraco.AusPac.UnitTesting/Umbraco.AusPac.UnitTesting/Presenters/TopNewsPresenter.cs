
using System;
using WebFormsMvp.Contrib.Presenters;
using WebFormsMvp.Contrib.Views;
using WebFormsMvp.Contrib.Data.Services;

namespace Umbraco.AusPac.UnitTesting.Presenters
{


	public class TopNewsPresenter : NewsArchivePresenter
	{
		public TopNewsPresenter(INewsArchiveView view, INewsService service) : base(view, service)
		{
		}
		
		public override void ReleaseView ()
		{
			base.ReleaseView ();
			
			//var service = this.dataService as IDisposable;
			//if (service != null) {
			//	service.Dispose();
			//}
		}

	}
}
