
using System;
using System.Linq;
using umbraco.Linq.Core.Node;
using System.Collections.Generic;
using WebFormsMvp.Contrib.Data.Models;

namespace Umbraco.AusPac.UnitTesting
{


	public class NewsService : WebFormsMvp.Contrib.Data.Services.INewsService, IDisposable
	{
		private NodeDataProvider dataProvider;
		private DemoDataContext ctx;
		
		public NewsService ()
		{
			this.dataProvider = new NodeDataProvider();
			this.ctx = new DemoDataContext(this.dataProvider);
		}
		
		public NewsService (string xmlPath)
		{
			this.dataProvider = new NodeDataProvider(xmlPath,false);
			this.ctx = new DemoDataContext(this.dataProvider);
		}
		
		#region INewsService implementation
		public IEnumerable<INewsArticle> GetNewsArticles ()
		{
			var articles =  from a in this.ctx.NewsArticles
							select a;
			
			return articles.Cast<INewsArticle>();
		}
		
		
		public WebFormsMvp.Contrib.Data.Models.INewsArticle GetNewsArticle (int id)
		{
			return this.ctx.NewsArticles.FirstOrDefault(n => n.Id == id);
		}
		
		#endregion

		#region IDisposable implementation
		void IDisposable.Dispose ()
		{
			if (this.dataProvider != null) {
				this.dataProvider.Dispose();
			}
			
			if (this.ctx != null) {
				this.ctx.Dispose();
			}
		}
		
		#endregion
	}
}
