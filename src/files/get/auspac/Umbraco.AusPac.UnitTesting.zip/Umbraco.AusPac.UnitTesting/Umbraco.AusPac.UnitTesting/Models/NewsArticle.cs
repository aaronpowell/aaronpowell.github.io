
using System;
using WebFormsMvp.Contrib.Data.Models;

namespace Umbraco.AusPac.UnitTesting
{


	public partial class NewsArticle : INewsArticle
	{
		#region INewsArticle implementation
		public string Headline {
			get {
				return this.Name;
			}
			set {
				this.Name = value;
			}
		}
		
		public Uri Link {
			get;set;
		}
		
		
		public string AuthorName {
			get{
				//This gets around a current limitation with accessing User/ Writer stuff
				//4.1 final will better expose this so you don't have a dependancy on
				//the businesslogic.dll assembly
				return "Az";
			}
			set{
				throw new NotImplementedException();	
			}
		}
		
		#endregion

	}
}
