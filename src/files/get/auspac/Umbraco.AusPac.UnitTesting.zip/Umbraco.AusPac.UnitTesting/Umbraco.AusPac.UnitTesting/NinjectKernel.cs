
using System;
using WebFormsMvp.Contrib.Ninject;
using WebFormsMvp.Contrib.Data.Services;
using Ninject.Core.Behavior;

namespace Umbraco.AusPac.UnitTesting
{


	public class NinjectKernel : MvpPresenterKernel
	{

		public NinjectKernel ()
		{
		}
		
		public override void SetupBindings ()
		{
			this.Bind<INewsService>().To<NewsService>().Using<OnePerRequestBehavior>();
		}


	}
}
