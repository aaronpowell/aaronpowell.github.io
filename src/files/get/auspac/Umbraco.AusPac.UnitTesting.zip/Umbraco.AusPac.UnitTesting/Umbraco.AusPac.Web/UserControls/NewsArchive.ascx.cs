﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebFormsMvp.Binder;
using WebFormsMvp;
using Umbraco.AusPac.UnitTesting.Presenters;
using WebFormsMvp.Contrib.Models;
using WebFormsMvp.Contrib.Views;
using WebFormsMvp.Web;

namespace Umbraco.AusPac.Web.UserControls
{
    [PresenterBinding(typeof(TopNewsPresenter))]
    public partial class NewsArchive : MvpUserControl<NewsArchiveModel>, INewsArchiveView
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region INewsArchiveView Members

        public int NumberOfArticles
        {
            get
            {
                return 10;
            }
            set
            {
                throw new NotSupportedException();
            }
        }

        #endregion
    }
}