using System.Web;
using WebFormsMvp.Contrib.Ninject;
using WebFormsMvp.Contrib.Data.Services;
using Umbraco.AusPac.UnitTesting;
using WebFormsMvp.Binder;

namespace Umbraco.AusPac.Web
{
    public class MvpModule : IHttpModule
    {
        #region IHttpModule Members

        public void Dispose()
        {
            
        }

        public void Init(HttpApplication context)
        {
            var presenterBinder = new NinjectKernel();

            PresenterBinder.Factory = presenterBinder;
        }

        #endregion
    }
}
