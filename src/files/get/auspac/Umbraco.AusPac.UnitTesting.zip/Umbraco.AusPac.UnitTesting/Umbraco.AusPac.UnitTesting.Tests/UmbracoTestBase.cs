
using System;
using NUnit.Framework;
using System.IO;
using System.Reflection;
using System.Xml.Linq;
using System.Threading;
using System.Globalization;

namespace Umbraco.AusPac.UnitTesting.Tests
{
	public abstract class UmbracoTestBase
	{
		protected string _umbracoXmlPath;
		
		[SetUp]
		public void SetUp() {
			this._umbracoXmlPath = Path.Combine(new FileInfo(Assembly.GetExecutingAssembly().Location).DirectoryName, "umbraco.config");
			Thread.CurrentThread.CurrentCulture = new CultureInfo("en-AU");
		}
		
		[Test]
		public void culture_is_en_AU() {
			var culture = Thread.CurrentThread.CurrentCulture.Name;
			Assert.AreEqual(culture, "en-AU", "Culture is actually: " + culture);
			               
		}
		
		[Test]
		public void umbraco_xml_path_valid() {
			var xdoc = XDocument.Load(this._umbracoXmlPath);
			
			Assert.IsNotNull(xdoc);
		}
	}
}
