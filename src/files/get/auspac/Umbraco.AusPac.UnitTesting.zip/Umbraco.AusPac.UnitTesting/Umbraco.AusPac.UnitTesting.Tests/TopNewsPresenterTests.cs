
using System;
using System.Linq;
using NUnit.Framework;
using Rhino.Mocks;
using WebFormsMvp.Contrib.Views;
using WebFormsMvp.Contrib.Models;
using WebFormsMvp.Contrib.Data.Services;
using System.Collections.Generic;
using WebFormsMvp.Contrib.Data.Models;
using Umbraco.AusPac.UnitTesting.Presenters;
using System.Reflection;

namespace Umbraco.AusPac.UnitTesting.Tests
{


	[TestFixture()]
	public class TopNewsPresenterTests : UmbracoTestBase
	{
		[Test()]
		public void loads_from_mock_service ()
		{
			//arrange
			var view = MockRepository.GenerateMock<INewsArchiveView>();
			var model = MockRepository.GenerateMock<NewsArchiveModel>();
			view.Expect(v => v.NumberOfArticles).Return(10);
			view.Expect(v => v.Model).Return(model);
			
			var service = MockRepository.GenerateMock<INewsService>();
			service.Expect(s => s.GetNewsArticles()).Return(new List<INewsArticle>());
			
			var presenter = new TopNewsPresenter(view, service);
			
			//act
			view.Raise(v => v.Load += null, this, EventArgs.Empty);
			presenter.ReleaseView();
			
			//assert
			Assert.IsTrue(view.Model.NewsArticles.Count() == 0, "There should be no articles");
			view.VerifyAllExpectations();
			model.VerifyAllExpectations();
			service.VerifyAllExpectations();
		}
		
		[Test()]
		public void article_count_filter_applied() 
		{
			//arrange
			var view = MockRepository.GenerateMock<INewsArchiveView>();
			var model = MockRepository.GenerateMock<NewsArchiveModel>();
			view.Expect(v => v.NumberOfArticles).Return(3);
			view.Expect(v => v.Model).Return(model);
			
			var service = MockRepository.GenerateMock<INewsService>();
			service.Expect(s => s.GetNewsArticles()).Return(new List<INewsArticle>(){
				MockRepository.GenerateMock<INewsArticle>(),
				MockRepository.GenerateMock<INewsArticle>(),
				MockRepository.GenerateMock<INewsArticle>(),
				MockRepository.GenerateMock<INewsArticle>(),
				MockRepository.GenerateMock<INewsArticle>()
			});
			
			var presenter = new TopNewsPresenter(view, service);
			
			//act
			view.Raise(v => v.Load += null, this, EventArgs.Empty);
			presenter.ReleaseView();
			
			//assert
			Assert.LessOrEqual(view.Model.NewsArticles.Count(), view.NumberOfArticles, "should have less than or equal to the number specified in the view");
			Assert.GreaterOrEqual(service.GetNewsArticles().Count(), view.Model.NewsArticles.Count());
			view.VerifyAllExpectations();
			model.VerifyAllExpectations();
			service.VerifyAllExpectations();
		}
		
		[Test]
		public void articles_read_from_linq_to_umbraco()
		{			
			//arrange
			var view = MockRepository.GenerateMock<INewsArchiveView>();
			var model = MockRepository.GenerateMock<NewsArchiveModel>();
			view.Expect(v => v.NumberOfArticles).Return(3);
			view.Expect(v => v.Model).Return(model);

			var service = new NewsService(this._umbracoXmlPath);
			
			var presenter = new TopNewsPresenter(view, service);
			
			//act
			view.Raise(v => v.Load += null, this, EventArgs.Empty);
			
			//assert
			Assert.LessOrEqual(view.Model.NewsArticles.Count(), view.NumberOfArticles, "should have less than or equal to the number specified in the view");

			presenter.ReleaseView();
			
			view.VerifyAllExpectations();
			model.VerifyAllExpectations();
			
		}
	}
}
