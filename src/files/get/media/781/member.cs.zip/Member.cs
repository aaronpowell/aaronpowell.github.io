﻿using System;
using umb = umbraco.cms.businesslogic.member;

namespace AaronPowell.Umbraco
{
    public abstract class Member
    {
        public virtual int MemberId { get; set; }
        public virtual string Email { get; set; }
        public virtual string LoginName { get; set; }
        public virtual string Password { get; set; }

        public bool IsDirty { get; set; }
        public virtual int MembershipTypeId { get; set; }
        public virtual int CreatingUserId { get; set; }

        public Member()
        {
            this.IsDirty = true;
        }

        public Member(int memberId) : this(new umb.Member(memberId)) { }

        private Member(umb.Member member)
        {
            this.MemberId = member.Id;
            this.Email = member.Email;
            this.Password = member.Password;
            this.LoginName = member.LoginName;

            this.PopulateCustomProperties(member);
        }

        protected abstract void PopulateCustomProperties(umb.Member member);
        protected abstract void PrepareMemberForSaving(umb.Member member);

        public virtual void Save()
        {
            umb.Member member = null;

            if (this.MemberId == 0)
            {
                if (string.IsNullOrEmpty(this.LoginName))
                {
                    throw new ArgumentNullException("Username");
                }
                member = umb.Member.MakeNew(this.LoginName, new umbraco.cms.businesslogic.member.MemberType(this.MembershipTypeId), new umbraco.BusinessLogic.User(this.CreatingUserId));
            }
            else
            {
                member = new umbraco.cms.businesslogic.member.Member(this.MemberId);
            }

            if (string.Compare(this.Password, member.Password) != 0)
            {
                member.Password = this.Password;
                this.IsDirty = true;
            }

            if (string.Compare(this.LoginName, member.LoginName) != 0)
            {
                member.LoginName = this.LoginName;
                this.IsDirty = true;
            }

            if (string.Compare(this.Email, member.Email) != 0)
            {
                member.Email = this.Email;
                this.IsDirty = true;
            }

            this.PrepareMemberForSaving(member);

            if (this.IsDirty)
            {
                member.Save();
                if (this.MemberId == 0)
                {
                    this.MemberId = member.Id;
                }
            }
        }

        private T getUmbProperty<T>(umb.Member m, string alias, T defaultValue)
        {
            if (m.getProperty(alias).Value == DBNull.Value)
            {
                return defaultValue;
            }
            else
            {
                return (T)m.getProperty(alias).Value;
            }
        }

        private static T getUmbEnumProperty<T>(umb.Member m, string key, T defaultValue)
        {
            if (m.getProperty(key).Value == DBNull.Value)
            {
                return defaultValue;
            }
            else
            {
                return (T)Enum.Parse(typeof(T), m.getProperty(key).Value.ToString());
            }
        }

        private static void setumbProperty<T>(umb.Member m, string key, T value)
        {
            m.getProperty(key).Value = value;
        }

        public static bool CheckUsername(string username)
        {
            return umb.Member.GetMemberFromLoginName(username) == null;
        }

        public static bool Login(string username, string password)
        {
            var member = umb.Member.GetMemberFromLoginNameAndPassword(username, password);
            if (member == null)
            {
                return false;
            }
            else
            {
                umb.Member.AddMemberToCache(member, false, new TimeSpan(1, 0, 0));
                return true;
            }
        }

        public static bool IsSomeoneLoggedIn()
        {
            return umb.Member.IsLoggedOn();
        }

        public static void Logout()
        {
            umb.Member.RemoveMemberFromCache(umb.Member.GetCurrentMember().Id);
        }
    }
}
