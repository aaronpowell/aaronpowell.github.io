﻿/// <reference name="MicrosoftAjax.js"/>
_ClientEventPool = function() {
    _ClientEventPool.initializeBase(this, null);
};
_ClientEventPool.prototype = {
    initialize: function() {
        _ClientEventPool.callBaseMethod(this, 'initialize');
        this._localEvents = this.get_events();
    },
    addEvent: function(eventName, handler) {
        this._localEvents.addHandler(eventName, handler);
    },
    removeEvent: function(eventName, handler) {
        this._localEvents.removeHandler(eventName, handler);
    },
    raiseEvent: function(eventName, sender, args) {
        var h = this._localEvents.getHandler(eventName);
        if (h) {
            h(sender, args);
        }
    }
};
_ClientEventPool.registerClass("_ClientEventPool", Sys.Component);
window.ClientEventPool = $create(_ClientEventPool, {"id":"ClientEventPool"}, null, null, null);