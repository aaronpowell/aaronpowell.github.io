CREATE DATABASE DDD
GO

USE [DDD]
GO
/****** Object:  Table [dbo].[Speaker]    Script Date: 04/23/2010 21:33:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Speaker](
	[SpeakerId] [int] IDENTITY(1,1) NOT NULL,
	[GivenName] [varchar](100) NOT NULL,
	[Surname] [varchar](100) NOT NULL,
	[Phone] [varchar](20) NOT NULL,
	[Email] [varchar](255) NOT NULL,
	[Company] [varchar](200) NULL,
	[Bio] [varchar](max) NOT NULL,
	[Website] [varchar](255) NULL,
	[TwitterId] [varchar](50) NULL,
	[DateCreated] [datetime] NOT NULL,
 CONSTRAINT [PK_Speakers] PRIMARY KEY CLUSTERED
(
	[SpeakerId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[SessionClosingDate]    Script Date: 04/23/2010 21:33:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SessionClosingDate](
	[SessionClosingDateId] [int] IDENTITY(1,1) NOT NULL,
	[ClosingDate] [datetime] NOT NULL,
 CONSTRAINT [PK_SessionClosingDate_1] PRIMARY KEY CLUSTERED
(
	[SessionClosingDateId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Sessions]    Script Date: 04/23/2010 21:33:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[Sessions](
	[SessionId] [int] IDENTITY(1,1) NOT NULL,
	[SpeakerId] [int] NOT NULL,
	[Title] [varchar](255) NOT NULL,
	[Abstract] [varchar](max) NOT NULL,
	[DateSubmitted] [datetime] NOT NULL,
	[Approved] [bit] NOT NULL CONSTRAINT [DF_Session_Approved]  DEFAULT ((0)),
	[Votes] [int] NOT NULL CONSTRAINT [DF_Sessions_Votes]  DEFAULT ((0)),
 CONSTRAINT [PK_Session] PRIMARY KEY CLUSTERED
(
	[SessionId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO
/****** Object:  ForeignKey [FK_Session_Speaker]    Script Date: 04/23/2010 21:33:06 ******/
ALTER TABLE [dbo].[Sessions]  WITH CHECK ADD  CONSTRAINT [FK_Session_Speaker] FOREIGN KEY([SpeakerId])
REFERENCES [dbo].[Speaker] ([SpeakerId])
GO
ALTER TABLE [dbo].[Sessions] CHECK CONSTRAINT [FK_Session_Speaker]
GO
