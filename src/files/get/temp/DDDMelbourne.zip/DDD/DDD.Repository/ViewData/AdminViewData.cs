﻿using System.Collections.Generic;

namespace Linq2Sql.Repository.ViewData
{
    public class AdminViewData
    {
        public IList<SessionViewData> SessionData { get; set; }
        public SessionClosingDateViewData SessionClosingData { get; set; }
    }
}
