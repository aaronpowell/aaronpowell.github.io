﻿using System;

namespace Linq2Sql.Repository.ViewData
{
    public class SessionClosingDateViewData
    {
        public int SessionClosingDateId { get; set; }
        public DateTime ClosingDate { get; set; }
    }
}
