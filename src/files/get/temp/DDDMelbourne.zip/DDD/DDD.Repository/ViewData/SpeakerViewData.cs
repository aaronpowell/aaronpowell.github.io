﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Linq2Sql.Repository.ViewData
{
    public class SpeakerViewData
    {
        public int SpeakerId { get; set; }

        [Required(ErrorMessage = "Given name is required")]
        [StringLength(100, ErrorMessage = "Given name cannot be more than 100 characters")]
        public string GivenName { get; set; }

        [Required(ErrorMessage = "Surname is required")]
        [StringLength(100, ErrorMessage = "Surname cannot be more than 100 characters")]
        public string Surname { get; set; }

        [Required(ErrorMessage = "Phone is required")]
        [StringLength(20, ErrorMessage = "Phone cannot be more than 20 characters")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [StringLength(255, ErrorMessage = "Email cannot be more than 255 characters")]
        [RegularExpression(@"([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Please enter a valid email address")]
        public string Email { get; set; }
        public string Company { get; set; }

        [Required(ErrorMessage = "Bio is required")]
        public string Bio { get; set; }


        public string Website { get; set; }
        public string TwitterId { get; set; }
        public DateTime DateCreated { get; set; }
    }
}
