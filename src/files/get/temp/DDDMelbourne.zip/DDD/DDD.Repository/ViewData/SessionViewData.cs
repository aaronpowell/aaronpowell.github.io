﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Linq2Sql.Repository.ViewData
{
    public class SessionViewData
    {
        public int SessionId { get; set; }
        public SpeakerViewData Speaker { get; set; }

        [Required(ErrorMessage = "Title is required")]
        [StringLength(255, ErrorMessage = "Title cannot be more than 255 characters")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Abstract is required")]
        public string Abstract { get; set; }

        public DateTime DateSubmitted { get; set; }
        public bool Approved { get; set; }
        public int Votes { get; set; }
        public int TotalRecords { get; set; }
    }
}
