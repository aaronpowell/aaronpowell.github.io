﻿using System.Collections.Generic;
using System.Linq;
using Linq2Sql.Model;
using Linq2Sql.Repository.ViewData;
using System;
using System.Web;

namespace Linq2Sql.Repository
{
    public class DDDRepository : IDDDRepository
    {
        private readonly DDDDataContext _dddDataContext;
        public DDDRepository(DDDDataContext dddDataContext)
        {
            _dddDataContext = dddDataContext;
        }

        public void AddSession(SessionViewData sessionViewData)
        {
            var speaker = new Speaker
                              {
                                  Bio = sessionViewData.Speaker.Bio,
                                  Company = sessionViewData.Speaker.Company,
                                  DateCreated = DateTime.Now,
                                  Email = sessionViewData.Speaker.Email,
                                  GivenName = sessionViewData.Speaker.GivenName,
                                  Phone = sessionViewData.Speaker.Phone,
                                  Surname = sessionViewData.Speaker.Surname,
                                  TwitterId = sessionViewData.Speaker.TwitterId,
                                  Website = sessionViewData.Speaker.Website
                              };
            
            _dddDataContext.Speakers.InsertOnSubmit(speaker);
            _dddDataContext.SubmitChanges();

            _dddDataContext.Sessions.InsertOnSubmit(new Sessions
                                                        {
                                                            Abstract = sessionViewData.Abstract,
                                                            Approved = false,
                                                            DateSubmitted = DateTime.Now,
                                                            SpeakerId = speaker.SpeakerId,
                                                            Title = sessionViewData.Title,
                                                            Votes = 0
                                                        });
            _dddDataContext.SubmitChanges();
        }

        public IList<SessionViewData> GetApprovedSessions(int skip, int take)
        {
            return (from p in _dddDataContext.Sessions
                    let count = _dddDataContext.Sessions.Where(o => o.Approved).Count()
                    where p.Approved
                    orderby p.Votes descending 
                    select new SessionViewData
                               {
                                   Abstract = HttpContext.Current.Server.HtmlEncode(p.Abstract),
                                   Approved = p.Approved,
                                   DateSubmitted = p.DateSubmitted,
                                   SessionId = p.SessionId,
                                   Title = HttpContext.Current.Server.HtmlEncode(p.Title),
                                   Votes = p.Votes,
                                   TotalRecords = count,
                                   Speaker = new SpeakerViewData
                                       {
                                           Bio = p.Speaker.Bio,
                                           Company = p.Speaker.Company,
                                           DateCreated = p.Speaker.DateCreated,
                                           Email = p.Speaker.Email,
                                           GivenName = p.Speaker.GivenName,
                                           Surname = p.Speaker.Surname,
                                           Phone = p.Speaker.Phone,
                                           SpeakerId = p.Speaker.SpeakerId,
                                           TwitterId = p.Speaker.TwitterId,
                                           Website = p.Speaker.Website
                                       }
                               }).Skip(skip).Take(take).ToList();
        }

        public AdminViewData GetAdminData()
        {
            var query = (from p in _dddDataContext.SessionClosingDates
                        select p).FirstOrDefault();

            return new AdminViewData
                                    {
                                        SessionClosingData = GetClosingDate(),
                                        SessionData = GetAllSessions()
                                    };
        }

        private SessionClosingDateViewData GetClosingDate()
        {
            return (from p in _dddDataContext.SessionClosingDates
                    select new SessionClosingDateViewData
                               {
                                   SessionClosingDateId = p.SessionClosingDateId,
                                   ClosingDate = p.ClosingDate
                               }).FirstOrDefault();
        }

        public IList<SessionViewData> GetAllSessions()
        {
            return (from p in _dddDataContext.Sessions
                    orderby p.Votes descending
                    select new SessionViewData
                    {
                        Abstract = p.Abstract,
                        Approved = p.Approved,
                        DateSubmitted = p.DateSubmitted,
                        SessionId = p.SessionId,
                        Title = HttpContext.Current.Server.HtmlEncode(p.Title),
                        Votes = p.Votes,
                        Speaker = new SpeakerViewData
                        {
                            Bio = p.Speaker.Bio,
                            Company = p.Speaker.Company,
                            DateCreated = p.Speaker.DateCreated,
                            Email = p.Speaker.Email,
                            GivenName = p.Speaker.GivenName,
                            Surname = p.Speaker.Surname,
                            Phone = p.Speaker.Phone,
                            SpeakerId = p.Speaker.SpeakerId,
                            TwitterId = p.Speaker.TwitterId,
                            Website = p.Speaker.Website
                        }
                    }).ToList();
        }

        public void ApproveSession(SessionViewData sessionViewData)
        {
            _dddDataContext.SubmitChanges();
        }

        public int VoteForSession(int sessionId)
        {
            var query = _dddDataContext.Sessions.Where(o => o.SessionId == sessionId).FirstOrDefault();
            if (query != null)
            {
                query.Votes = query.Votes + 1;
                _dddDataContext.SubmitChanges();
                return query.Votes;
            }
            else
            {
                throw new Exception("Session not found!");
            }
        }

        /// <summary>
        /// If the current date is greater than what's in the database,
        /// then the sessions are closed.
        /// </summary>
        /// <returns></returns>
        public bool SessionsAreClosed()
        {
            var query = (from p in _dddDataContext.SessionClosingDates
                        select p).FirstOrDefault();
            return DateTime.Compare(DateTime.Now, query.ClosingDate) == 1; 
        }

        public void UpdateSessionInformation(AdminViewData adminViewData)
        {
            var closingDate = (from p in _dddDataContext.SessionClosingDates select p)
                                .FirstOrDefault();
            closingDate.ClosingDate = adminViewData.SessionClosingData.ClosingDate;

            foreach (var item in adminViewData.SessionData)
            {
                var session = (from p in _dddDataContext.Sessions
                               where p.SessionId == item.SessionId
                               select p).FirstOrDefault();
                session.Approved = item.Approved;
            }

            _dddDataContext.SubmitChanges();
        }
    }
}
