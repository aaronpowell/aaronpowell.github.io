﻿using System.Collections.Generic;
using Linq2Sql.Repository.ViewData;

namespace Linq2Sql.Service
{
    public interface IDDDService
    {
        void AddSession(SessionViewData sessionViewData);

        IList<SessionViewData> GetApprovedSessions(int skip, int take);

        AdminViewData GetAdminData();

        void ApproveSession(SessionViewData sessionViewData);

        int VoteForSession(int sessionId);

        bool SessionsAreClosed();

        void UpdateSessionInformation(AdminViewData adminViewData);
    }
}
