﻿using System;
using System.Collections.Generic;
using Linq2Sql.Repository;
using Linq2Sql.Repository.ViewData;

namespace Linq2Sql.Service
{
    public class DDDService : IDDDService
    {
        private readonly IDDDRepository _dddRepository;
        public DDDService(IDDDRepository dddRepository)
        {
            _dddRepository = dddRepository;
        }

        public void AddSession(SessionViewData sessionViewData)
        {
            _dddRepository.AddSession(sessionViewData);
        }

        public IList<SessionViewData> GetApprovedSessions(int skip, int take)
        {
            return _dddRepository.GetApprovedSessions(skip, take);
        }

        public AdminViewData GetAdminData()
        {
            return _dddRepository.GetAdminData();
        }

        public void ApproveSession(SessionViewData sessionViewData)
        {
            _dddRepository.ApproveSession(sessionViewData);
        }

        public int VoteForSession(int sessionId)
        {
            return _dddRepository.VoteForSession(sessionId);
        }

        public bool SessionsAreClosed()
        {
            return _dddRepository.SessionsAreClosed();
        }

        public void UpdateSessionInformation(AdminViewData adminViewData)
        {
            _dddRepository.UpdateSessionInformation(adminViewData);
        }
    }
}
