﻿$(function() {
    process.pageData();
    $("#sessionContent img").live("click", function(e) {
        e.preventDefault();
        $.blockUI({
            message: '<img src="../../Content/images/ajax-loader.gif" /><span class=class=blockText>Casting your vote!  Please wait...</span>'
        });
        $("#VoteForSession").trigger("submit", { sessionId: $(this).next().val() });
    });

    $("#VoteForSession").submit(function(e, sessionId) {
        e.preventDefault();
        $.post(this.action, sessionId, function(d) {
            if (!d.MaximumVotesReached) {
                $("#voteSessionid" + d.SessionId).text(d.Count);
            }

            $.unblockUI();
            if (d.MaximumVotesReached) {
                $.blockUI({
                    message: "<span class=class=blockText>Maximum votes have been reached for this session!</span>",
                    overlayCSS: { backgroundColor: "#ff0000" },
                    timeout: 3000
                });
            }
        });
    });
});

var process = function() {
    return {
        template: function(element, data, url) {
            element.setTemplateURL(url).processTemplate(data);
        },
        pageData: function() {
            var pageSize = 5;
            var skip = arguments.length === 0 ? 0 : (arguments[0] * pageSize) - pageSize;
            
            $.blockUI({
                message: '<img src="../../Content/images/ajax-loader.gif" /><span class=blockText>Fetching sessions!  Please wait...</span>' 
            });
            $.getJSON("/DDD/GetApprovedSessions", { skip: skip, take: pageSize }, function(data) {
                process.template($("#SessionPlaceHolder"), data, "/Templates/Sessions.htm");
                var total = data.SessionData[0].TotalRecords;
                if (total > 0) {
                    // Get the page count by dividing the total records
                    // by the page size. This has to be rounded up
                    // otherwise you might not get the last page
                    var pageTotal = Math.ceil(total / pageSize);
                    var data = [];
                    for (var i = 0; i < pageTotal; i++) {
                        data.push("<a href=\"#\" onClick=\"process.pageData(" + (i + 1) + ")\">" + (i + 1) + "</a>&nbsp;");
                    }
                    $("#paging").text("").append(data.join(" "));
                }
                $.unblockUI();
            });
        }
    }
} ();