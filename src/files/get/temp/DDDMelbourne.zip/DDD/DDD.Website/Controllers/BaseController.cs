﻿using System.Web.Mvc;
using System.Web.Routing;

namespace Linq2SqlDemo.Controllers
{
    public class BaseController : Controller
    {
        protected override void OnException(ExceptionContext filterContext)
        {
            if (filterContext.Exception != null)
            {
                filterContext.ExceptionHandled = true;
                RedirectToRoute(new RouteValueDictionary
                {
                    { "controller", "Error"},
                    { "action", "Index" }
                });
            }
            base.OnException(filterContext);
        }
    }
}
