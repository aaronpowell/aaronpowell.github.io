﻿using System;
using System.Web.Mvc;
using Linq2Sql.Service;
using Linq2Sql.Repository.ViewData;

namespace Linq2SqlDemo.Controllers
{
    [HandleError]
    public class DDDController : BaseController
    {
        private const int maximumVotesPerSession = 5;
        private readonly IDDDService _dddService;

        public DDDController(IDDDService dddService)
        {
            _dddService = dddService;
        }

        public ActionResult Home()
        {
            return View();
        }

        public ActionResult FAQ()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Location()
        {
            return View();
        }

        [HttpGet]
        public ActionResult AddSession()
        {
            ViewData["SessionsAreClosed"] = _dddService.SessionsAreClosed();
            return View();
        }

        [HttpGet]
        public ActionResult ViewSessions()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetApprovedSessions(int skip, int take)
        {
            return Json(new
            {
                SessionData = _dddService.GetApprovedSessions(skip, take)
            }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [ValidateAntiForgeryToken(Salt = "AddSession")]
        public ActionResult AddSession([Bind(Exclude = "SpeakerId,DateCreated,Approved,DateSubmitted,Votes")]SessionViewData sessionViewData)
        {
            if (!ModelState.IsValid)
            {
                ViewData["SessionsAreClosed"] = _dddService.SessionsAreClosed();
                return View(sessionViewData);
            }
            else
            {
                _dddService.AddSession(sessionViewData);
                return RedirectToAction("ViewSessions");
            }
        }

        [HttpPost]
        public JsonResult VoteForSession(int sessionId)
        {
            if (Session["NumberOfVotes"] == null)
            {
                Session["NumberOfVotes"] = 1;
            }
            var count = Convert.ToInt32(Session["NumberOfVotes"]);

            try
            {
                var data = new
                               {
                                   Count = count <= maximumVotesPerSession ? _dddService.VoteForSession(sessionId) : 0,
                                   SessionId = sessionId,
                                   MaximumVotesReached = count <= maximumVotesPerSession ? false : true
                };
                Session["NumberOfVotes"] = count + 1;
                return Json(data);
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public ActionResult Sessions()
        {
            return View();
        }
    }
}
