﻿using System.Web.Mvc;

namespace Linq2SqlDemo.Controllers
{
    public class ErrorController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

    }
}
