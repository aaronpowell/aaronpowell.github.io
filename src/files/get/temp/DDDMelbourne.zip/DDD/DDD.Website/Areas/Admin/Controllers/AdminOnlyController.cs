﻿using System.Web.Mvc;
using Linq2Sql.Service;
using Linq2Sql.Repository.ViewData;

namespace Linq2SqlDemo.Areas.Admin.Controllers
{
    public class AdminOnlyController : Controller
    {
        private readonly IDDDService _dddService;
        public AdminOnlyController(IDDDService dddService)
        {
            _dddService = dddService;
        }

        public ActionResult Index()
        {
            return View(_dddService.GetAdminData());
        }

        [HttpPost]
        [ValidateAntiForgeryToken(Salt = "UpdateSessionClosingDate")]
        public JsonResult UpdateSessionInformation(AdminViewData adminViewData)
        {
            _dddService.UpdateSessionInformation(adminViewData);
            return Json("Saved!");
        }
    }
}
