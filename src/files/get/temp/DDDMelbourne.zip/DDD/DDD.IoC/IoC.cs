﻿using System.Web.Mvc;
using Linq2Sql.Model;
using StructureMap;

namespace Linq2SqlIoC
{
    public static class IoC
    {
        public static void StructureMapConfiguration()
        {
            ObjectFactory.Initialize(InitializeUsingScanning);
        }

        private static void InitializeUsingScanning(IInitializationExpression obj)
        {
            obj.For<DDDDataContext>().HttpContextScoped().Use(c => new DDDDataContext());
            obj.Scan(y =>
            {
                y.AddAllTypesOf<Controller>();
                y.AssembliesFromApplicationBaseDirectory();
                y.WithDefaultConventions();
            });
        }
    }
}
